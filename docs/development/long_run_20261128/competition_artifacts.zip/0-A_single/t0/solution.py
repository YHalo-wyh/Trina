def solve(values, target):
    seen, total, answer = {0: 1}, 0, 0
    for value in values:
        total += value
        answer += seen.get(total - target, 0)
        seen[total] = seen.get(total, 0) + 1
    return answer
