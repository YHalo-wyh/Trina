import importlib.util,json,pathlib,time,sys
spec=importlib.util.spec_from_file_location('submission',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
import itertools
for length in range(6):
    for values in itertools.product((-1, 0, 2), repeat=length):
        for target in (-2, 0, 2):
            expected = sum(sum(values[a:b]) == target for a in range(length) for b in range(a+1, length+1))
            assert module.solve(list(values), target) == expected, (values, target)
pathlib.Path(__file__).with_name('validation.json').write_text(json.dumps({'passed':True,'verified_at':time.time()}))
print('OK')
