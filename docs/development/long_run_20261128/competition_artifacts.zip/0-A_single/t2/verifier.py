import importlib.util,json,pathlib,time,sys
spec=importlib.util.spec_from_file_location('submission',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
for source, expected in [([], []), ([[1,3],[2,4],[9,10]], [[1,4],[9,10]]),
                         ([[-4,-1],[-1,3],[0,0]], [[-4,3]]), ([[2,2],[2,2]], [[2,2]])]:
    assert module.solve(source) == expected
pathlib.Path(__file__).with_name('validation.json').write_text(json.dumps({'passed':True,'verified_at':time.time()}))
print('OK')
