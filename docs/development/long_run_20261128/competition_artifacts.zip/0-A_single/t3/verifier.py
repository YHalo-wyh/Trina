import importlib.util,json,pathlib,time,sys
spec=importlib.util.spec_from_file_location('submission',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
import itertools
for length in range(7):
    for chars in itertools.product(('a', '中'), repeat=length):
        source = ''.join(chars)
        result = module.solve(source)
        assert ''.join(char * count for char, count in result) == source
        assert all(count > 0 for char, count in result)
        assert all(a[0] != b[0] for a, b in zip(result, result[1:]))
pathlib.Path(__file__).with_name('validation.json').write_text(json.dumps({'passed':True,'verified_at':time.time()}))
print('OK')
