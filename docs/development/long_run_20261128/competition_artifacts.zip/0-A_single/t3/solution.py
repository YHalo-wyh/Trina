def solve(text):
    result = []
    for char in text:
        if result and result[-1][0] == char: result[-1][1] += 1
        else: result.append([char, 1])
    return result
