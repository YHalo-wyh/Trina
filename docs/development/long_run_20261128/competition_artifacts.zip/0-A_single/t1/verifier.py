import importlib.util,json,pathlib,time,sys
spec=importlib.util.spec_from_file_location('submission',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
for n, edges in [(0, []), (4, [(0, 2), (1, 2), (2, 3)]), (3, []), (2, [(0, 1), (1, 0)])]:
    result = module.solve(n, edges)
    if edges == [(0, 1), (1, 0)]: assert result is None
    else:
        assert sorted(result) == list(range(n))
        assert all(result.index(a) < result.index(b) for a, b in edges)
pathlib.Path(__file__).with_name('validation.json').write_text(json.dumps({'passed':True,'verified_at':time.time()}))
print('OK')
