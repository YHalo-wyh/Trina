def solve(n, edges):
    import heapq
    graph, indegree = [[] for _ in range(n)], [0] * n
    for a, b in edges:
        graph[a].append(b)
        indegree[b] += 1
    ready, result = [i for i in range(n) if not indegree[i]], []
    heapq.heapify(ready)
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for other in graph[node]:
            indegree[other] -= 1
            if not indegree[other]: heapq.heappush(ready, other)
    return result if len(result) == n else None
