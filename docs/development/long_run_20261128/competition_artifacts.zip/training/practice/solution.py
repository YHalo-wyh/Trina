def solve(value):
    return isinstance(value, list) and all(type(item) is int for item in value)
