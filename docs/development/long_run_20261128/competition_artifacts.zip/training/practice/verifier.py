import importlib.util,json,pathlib,time,sys
spec=importlib.util.spec_from_file_location('submission',sys.argv[1])
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
for value, expected in [([], True), ([1,-2], True), ([True], False), ([1.5], False), ('text', False)]:
    assert module.solve(value) == expected
pathlib.Path(__file__).with_name('validation.json').write_text(json.dumps({'passed':True,'verified_at':time.time()}))
print('OK')
