"""带护栏的 HTTP 客户端：所有 Web 类请求的唯一出口。

特性：自动过 ScopeGuard 校验 → 限速 → 记录证据 → 统一超时/UA/重定向策略。
工具层不要直接 `requests.get`，否则绕过审计与护栏。
"""

from __future__ import annotations

import time
import warnings
from dataclasses import dataclass, field
from html import unescape
from typing import Any
from urllib.parse import urljoin, urlsplit, urlunsplit

import requests

from .. import __version__
from ..scope import Decision, ScopeGuard
from ..traffic import capture_http

DEFAULT_UA = f"Trina/{__version__}"
DEFAULT_HEADERS = {
    "User-Agent": DEFAULT_UA,
    "Accept": "*/*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Connection": "close",
}


@dataclass
class HttpResult:
    """一次 HTTP 交互的完整记录（同时作为证据）。"""

    url: str
    method: str = "GET"
    status: int = 0
    headers: dict[str, str] = field(default_factory=dict)
    body: str = ""
    elapsed: float = 0.0
    error: str = ""
    payload: str = ""
    request_headers: dict[str, str] = field(default_factory=dict)
    request_body: str = ""
    history: list[str] = field(default_factory=list)
    traffic_id: str = ""
    body_truncated: bool = False

    @property
    def ok(self) -> bool:
        return not self.error and 0 < self.status < 600

    @property
    def length(self) -> int:
        return len(self.body or "")

    @property
    def title(self) -> str:
        body = self.body or ""
        lower = body.lower()
        start = lower.find("<title")
        if start < 0:
            return ""
        start = lower.find(">", start) + 1
        end = lower.find("</title>", start)
        return unescape(body[start:end].strip())[:120] if end > start else ""

    def excerpt(self, limit: int = 400) -> str:
        text = (self.body or "").replace("\r", "")
        return text[:limit]

    def to_dict(self, *, include_body: bool = True, body_limit: int = 1200) -> dict[str, Any]:
        data = {
            "traffic_id": self.traffic_id,
            "url": self.url,
            "method": self.method,
            "status": self.status,
            "length": self.length,
            "elapsed": round(self.elapsed, 3),
            "error": self.error,
            "title": self.title,
            "redirects": self.history[:5],
        }
        if self.payload:
            data["payload"] = self.payload
        if self.request_body:
            data["request_body"] = self.request_body[:body_limit]
        if include_body:
            data["body_excerpt"] = self.excerpt(body_limit)
        return data

    def as_evidence(self, kind: str = "http", note: str = "", **extra: Any) -> dict[str, Any]:
        evidence = {
            "traffic_id": self.traffic_id,
            "kind": kind,
            "target": self.url,
            "method": self.method,
            "status": self.status,
            "request": {
                "method": self.method,
                "url": self.url,
                "headers": {k: v for k, v in (self.request_headers or {}).items() if k.lower() not in ("cookie", "authorization", "proxy-authorization", "x-api-key", "mcp-session-id")},
                "body": (self.request_body or "")[:600],
            },
            "response": {"status": self.status, "length": self.length, "body_excerpt": self.excerpt(600)},
            "payload": self.payload,
            "note": note,
        }
        evidence.update(extra)
        return evidence


class HttpClient:
    """受护栏约束的 HTTP 会话。"""

    def __init__(
        self,
        guard: ScopeGuard,
        *,
        timeout: float = 15.0,
        retries: int = 1,
        verify_tls: bool = False,
        headers: dict[str, str] | None = None,
        actor: str = "trina",
        session: requests.Session | None = None,
    ):
        self.guard = guard
        self.timeout = timeout
        self.retries = retries
        self.actor = actor
        self.session = session or requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)
        if headers:
            self.session.headers.update(headers)
        self.session.verify = verify_tls
        self.session.max_redirects = 5
        self.requests_made = 0
        self.bytes_received = 0
        self.denials: list[Decision] = []

    # ------------------------------------------------------------------ 核心
    def request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        data: Any = None,
        json_body: Any = None,
        headers: dict[str, str] | None = None,
        cookies: dict[str, str] | None = None,
        allow_redirects: bool = True,
        timeout: float | None = None,
        required_level: str = "detect",
        payload_label: str = "",
        files: Any = None,
        control_plane: bool = False,
    ) -> HttpResult:
        """逐跳、逐次重试校验实际请求；护栏拒绝作为失败结果返回。

        `control_plane=True` 时走 `ScopeGuard.check_control_plane`：只允许显式登记的
        答题 API 主机，不按靶场目标网段判定（控制面不是渗透目标）。
        """
        started = time.monotonic()
        history: list[str] = []

        def failure(message: str, request: requests.PreparedRequest | None = None) -> HttpResult:
            return capture_http(HttpResult(
                url=request.url if request is not None else url,
                method=request.method if request is not None else method.upper(),
                error=message, elapsed=time.monotonic() - started,
                payload=payload_label, history=list(history),
            ))

        def denied(decision: Decision, request: requests.PreparedRequest) -> HttpResult:
            self.denials.append(decision)
            return failure(f"[护栏拒绝:{decision.category}] {decision.reason}", request)

        try:
            prepared = self.session.prepare_request(requests.Request(
                method.upper(), url, params=params, data=data, json=json_body,
                files=files, headers=headers, cookies=cookies,
            ))
        except (requests.exceptions.RequestException, ValueError) as exc:
            return failure(f"{type(exc).__name__}: {exc}")

        while True:
            body_text = prepared.body or ""
            if isinstance(body_text, bytes):
                body_text = body_text.decode("utf-8", "replace")
            elif not isinstance(body_text, str):
                return failure("不支持无法校验和重放的流式请求体", prepared)
            # 写入类请求连接失败时可能已被服务端处理，不自动重复提交。
            retries = max(0, self.retries) if prepared.method in ("GET", "HEAD", "OPTIONS") else 0
            for attempt in range(retries + 1):
                if control_plane:
                    decision = self.guard.check_control_plane(prepared.url, method=prepared.method)
                else:
                    decision = self.guard.check_http(
                        prepared.url, method=prepared.method, body=body_text, required_level=required_level,
                    )
                if decision.denied:
                    return denied(decision, prepared)
                wait = self.guard.throttle(urlsplit(prepared.url).hostname or "")
                if wait > 0:
                    time.sleep(min(wait, 5.0))
                self.requests_made += 1
                try:
                    from ..scope import execution_budget
                    request_timeout = execution_budget(timeout or self.timeout)
                    settings = self.session.merge_environment_settings(prepared.url, {}, False, None, None)
                    # 关闭 TLS 校验是靶场兼容选项；urllib3 的 InsecureRequestWarning
                    # 不能越过展示边界污染全屏 TUI。仅在这一请求范围抑制该类别，
                    # 其他网络告警仍照常出现。
                    with warnings.catch_warnings():
                        if self.session.verify is False:
                            from urllib3.exceptions import InsecureRequestWarning

                            warnings.simplefilter("ignore", InsecureRequestWarning)
                        response = self.session.send(
                            prepared, allow_redirects=False, timeout=request_timeout, **settings,
                        )
                    break
                except requests.exceptions.RequestException as exc:
                    if attempt >= retries:
                        return failure(f"{type(exc).__name__}: {exc}", prepared)
                    time.sleep(0.4 * (attempt + 1))

            try:
                body = response.text[:200_000]
                self.bytes_received += len(body)
                recorded = capture_http(HttpResult(
                    url=prepared.url, method=prepared.method, status=response.status_code,
                    headers=dict(response.headers), body=body, elapsed=time.monotonic() - started,
                    payload=payload_label or body_text[:300], request_headers=dict(prepared.headers),
                    request_body=body_text[:200_000], history=list(history),
                    body_truncated=len(response.text) > 200_000 or len(body_text) > 200_000,
                ))
                # Requests 只准备下一跳（含方法改写、Cookie 和 307/308 请求体），不发送。
                following = response.next if allow_redirects else None
                if following is None:
                    return recorded
                if len(history) >= self.session.max_redirects:
                    return failure(f"重定向次数超过上限 {self.session.max_redirects}", prepared)
                history.append(prepared.url)
                if control_plane:
                    decision = self.guard.check_control_plane(following.url, method=following.method)
                else:
                    decision = self.guard.check_http_redirect(prepared.url, following.url)
                if decision.denied:
                    return denied(decision, following)
                prepared = following
            finally:
                response.close()

    async def arequest(self, session, method: str, url: str, *, timeout: float = 8.0) -> HttpResult:
        """异步扫描的传输适配；不自动跟随重定向，每次出网独立校验。"""
        import asyncio
        import aiohttp
        decision = self.guard.check_http(url, method=method, required_level="detect")
        if decision.denied:
            self.denials.append(decision)
            return HttpResult(url=url, method=method, error=decision.reason)
        wait = self.guard.throttle(urlsplit(url).hostname or "")
        if wait > 0:
            await asyncio.sleep(wait)
        decision = self.guard.check_http(url, method=method, required_level="detect")
        if decision.denied:
            return HttpResult(url=url, method=method, error=decision.reason)
        from ..scope import execution_budget
        timeout = execution_budget(timeout)
        self.requests_made += 1
        started = time.monotonic()
        try:
            async with session.request(method, url, allow_redirects=False, timeout=aiohttp.ClientTimeout(total=timeout)) as response:
                raw = await response.content.read(200_001)
                self.bytes_received += len(raw)
                return capture_http(HttpResult(url=str(response.url), method=method, status=response.status, headers=dict(response.headers),
                                  body=raw[:200_000].decode("utf-8", "replace"), elapsed=time.monotonic() - started,
                                  body_truncated=len(raw) > 200_000))
        except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as exc:
            return capture_http(HttpResult(url=url, method=method, error=f"{type(exc).__name__}: {exc}"))

    # ------------------------------------------------------------------ 便捷
    def get(self, url: str, **kwargs: Any) -> HttpResult:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs: Any) -> HttpResult:
        return self.request("POST", url, **kwargs)

    def head(self, url: str, **kwargs: Any) -> HttpResult:
        return self.request("HEAD", url, **kwargs)

    def stats(self) -> dict[str, Any]:
        return {
            "requests": self.requests_made,
            "bytes": self.bytes_received,
            "denied": len(self.denials),
        }


def normalize_url(base: str, path: str) -> str:
    """把 base + path 组合成绝对 URL（保留 base 的 scheme/host）。"""
    if not path:
        return base
    if path.startswith(("http://", "https://")):
        return path
    return urljoin(base.rstrip("/") + "/", path.lstrip("/"))


def origin(url: str) -> str:
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, "", "", ""))
