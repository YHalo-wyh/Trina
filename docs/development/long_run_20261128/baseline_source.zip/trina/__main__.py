"""`python -m trina` 入口。"""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
