"""Trina 工具执行守卫。

任何出网动作（工具调用、外部二进制、HTTP 请求）在真正执行前都必须经过本模块。
默认 ``scope.trust_mode=full``，已注册工具直接执行；显式切到 ``restricted`` 时恢复旧边界。

受限模式的三层防线
------------------
1. 目标校验 `check_target`：解析目标 → 全部 IP 必须落在授权网段且不在拒绝网段；
   受限模式默认拒绝公网（`allow_public=false`）；回环受 `allow_loopback` 控制。
2. 动作等级 `check_action_level`：detect(只读) < verify(可验证) < exploit(命令执行/批量爆破)，
   超过 `scope.exploit_level` 的动作直接拒绝。
3. 禁止清单 `check_argv`：DoS、系统破坏、数据导出、外带写文件等模式。

``full`` 模式不做上述授权拒绝，但仍保留格式/参数校验、审计、超时、取消与限速。
"""

from __future__ import annotations

import ipaddress
import random
from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
import threading
import re
import socket
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable
from urllib.parse import unquote_plus, urlsplit

from .config import ACTION_LEVELS, ScopeConfig

def read_provider_catalog(url: str, headers: dict[str, str], timeout: float) -> dict:
    """只读取所选供应商的模型目录，带凭据的请求不跟随重定向。"""
    import json
    import urllib.request
    from .providers import validate_address

    # 分页参数由调用方编码，连接地址沿用供应商表单校验。
    validate_address(url.split("?", 1)[0])

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    request = urllib.request.Request(url, headers={**headers, "Accept": "application/json"})
    with urllib.request.build_opener(NoRedirect).open(request, timeout=timeout) as response:
        raw = response.read(8 * 1024 * 1024 + 1)
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("模型目录响应过大")
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("模型目录格式错误")
    return data


class _ModelStreamResponse:
    """只消耗已经到达的字节，保留 SSE 的逐行时序。"""

    def __init__(self, raw, *, pooled: bool):
        self.raw = raw
        self.pooled = pooled

    def __iter__(self):
        if not self.pooled:
            yield from self.raw
            return
        pending = b""
        while chunk := self.raw.read1(8192):
            *lines, pending = (pending + chunk).split(b"\n")
            yield from (line + b"\n" for line in lines)
        if pending:
            yield pending

    def read_tail(self, seconds: float = .025) -> bytes:
        """尝试收完终止事件后的 HTTP 帧；等待过久就让该连接退出复用。"""
        from urllib3.exceptions import HTTPError

        if not self.pooled or self.raw.closed:
            return b""
        connection = self.raw.connection
        sock = connection.sock if connection is not None else None
        if sock is None:
            fp = getattr(getattr(self.raw, "_fp", None), "fp", None)
            sock = getattr(getattr(fp, "raw", None), "_sock", None)
        if sock is None:
            return b""
        timeout = sock.gettimeout()
        try:
            sock.settimeout(seconds if timeout is None else min(seconds, timeout))
            return self.raw.read1(8192)
        except (HTTPError, OSError, ValueError):
            return b""
        finally:
            if sock.fileno() >= 0:
                sock.settimeout(timeout)


_INTERACTIVE_RECONNECT: ContextVar[tuple[int, threading.Event] | None] = ContextVar(
    "trina_interactive_reconnect", default=None,
)


class ModelRetryCancelled(InterruptedError):
    """操作者取消模型重连。"""


@contextmanager
def interactive_model_retries(max_attempts: int, stop: threading.Event):
    """把交互轮次的重连配置与停止信号绑定到当前线程。"""
    token = _INTERACTIVE_RECONNECT.set((max_attempts, stop))
    try:
        yield
    finally:
        _INTERACTIVE_RECONNECT.reset(token)


class ModelStreamTransport:
    """模型 SSE 复用连接，保留系统代理和证书。"""

    def __init__(self):
        self._route = None
        self._pool = None

    @staticmethod
    def _manager(proxy: str):
        import ssl
        from urllib.parse import unquote, urlunsplit
        from urllib3 import PoolManager, ProxyManager
        from urllib3.connection import HTTPConnection, HTTPSConnection
        from urllib3.connectionpool import HTTPConnectionPool, HTTPSConnectionPool
        from urllib3.util import make_headers

        class MeasuredConnect:
            def connect(self):
                started = time.perf_counter()
                super().connect()
                self.trina_connect = started, time.perf_counter() - started

        class TimedHTTP(MeasuredConnect, HTTPConnection):
            pass

        class TimedHTTPS(MeasuredConnect, HTTPSConnection):
            pass

        class TimedHTTPPool(HTTPConnectionPool):
            ConnectionCls = TimedHTTP

        class TimedHTTPSPool(HTTPSConnectionPool):
            ConnectionCls = TimedHTTPS

        options = dict(num_pools=2, maxsize=2, ssl_context=ssl.create_default_context())
        if proxy:
            parts = urlsplit(proxy)
            proxy_auth = (make_headers(proxy_basic_auth=f"{unquote(parts.username)}:{unquote(parts.password or '')}")
                          if parts.username is not None else None)
            address = urlunsplit((parts.scheme, parts.netloc.rsplit("@", 1)[-1], parts.path, "", ""))
            manager = ProxyManager(address, proxy_headers=proxy_auth, **options)
        else:
            manager = PoolManager(**options)
        manager.pool_classes_by_scheme = {"http": TimedHTTPPool, "https": TimedHTTPSPool}
        return manager

    @contextmanager
    def open(self, request, timeout: float, timing: dict, *,
             on_retry: Callable[[int, float, int], None] | None = None):
        from http.client import RemoteDisconnected
        from urllib.error import URLError
        from urllib3.exceptions import ProtocolError

        interactive = _INTERACTIVE_RECONNECT.get()
        limit = interactive[0] if interactive is not None else 2
        stop = interactive[1] if interactive is not None else None
        for attempt in range(limit + 1):
            if stop is not None and stop.is_set():
                raise ModelRetryCancelled("已停止模型请求")
            with ExitStack() as response_scope:
                try:
                    response = response_scope.enter_context(self._open_once(request, timeout, timing))
                except (OSError, ProtocolError) as exc:
                    cause = exc.reason if isinstance(exc, URLError) else exc
                    if isinstance(cause, ProtocolError) and cause.args:
                        cause = cause.args[-1]
                    if not isinstance(cause, RemoteDisconnected):
                        raise
                    if attempt == limit:
                        if not attempt:
                            raise
                        raise RemoteDisconnected(f"{cause}（自动重连 {attempt} 次后仍未收到响应）") from exc
                    if stop is not None:
                        ceiling = .5 * 2 ** min(attempt, 4)
                        delay = round(random.uniform(.75 * ceiling, ceiling), 3)
                    else:
                        delay = (.25, .75)[attempt]
                    if on_retry is not None:
                        on_retry(attempt + 1, delay, limit)
                    if stop is None:
                        time.sleep(delay)
                    elif stop.wait(delay):
                        raise ModelRetryCancelled("已取消模型重连") from exc
                    continue
                # 响应头已到达。流读取在重连处理范围之外。
                yield response
                return

    @contextmanager
    def _open_once(self, request, timeout: float, timing: dict):
        import io
        import urllib.error
        import urllib.request
        from urllib3.response import HTTPResponse

        parts = urlsplit(request.full_url)
        proxy = urllib.request.getproxies().get(parts.scheme) if not urllib.request.proxy_bypass(parts.netloc) else ""
        proxy = proxy or ""
        if proxy and "://" not in proxy:
            proxy = "http://" + proxy
        # 旧版 urllib3 缺少 read1，保留原有逐行传输以免流式输出被缓冲。
        if not hasattr(HTTPResponse, "read1") or (proxy and urlsplit(proxy).scheme not in {"http", "https"}):
            with urllib.request.urlopen(request, timeout=timeout) as raw:
                yield _ModelStreamResponse(raw, pooled=False)
            return
        if proxy != self._route:
            pool = self._manager(proxy)
            if self._pool is not None:
                self._pool.clear()
            self._pool, self._route = pool, proxy
        started = time.perf_counter()
        headers = dict(request.header_items())
        headers["Accept-Encoding"] = "identity"
        raw = self._pool.request(request.get_method(), request.full_url, body=request.data, headers=headers,
                                 preload_content=False, redirect=False, retries=False, timeout=timeout)
        try:
            timing["headers_seconds"] = round(time.perf_counter() - started, 4)
            stamp = getattr(raw.connection, "trina_connect", None)
            if stamp:
                timing["connection_reused"] = stamp[0] < started
                timing["connect_seconds"] = 0.0 if stamp[0] < started else round(stamp[1], 4)
            response = _ModelStreamResponse(raw, pooled=True)
            if not 200 <= raw.status < 300:
                body = response.read_tail(seconds=1.0)
                raise urllib.error.HTTPError(request.full_url, raw.status, raw.reason, raw.headers, io.BytesIO(body))
            yield response
        finally:
            raw.close()
            raw.release_conn()


@dataclass
class ExecutionLease:
    """单次工具调用的可撤销执行租约，不是目标授权来源。"""
    deadline: float
    cancelled: threading.Event = field(default_factory=threading.Event)

    def check(self) -> None:
        if self.cancelled.is_set() or time.monotonic() >= self.deadline:
            raise RuntimeError("本次工具调用已超时或取消")


_EXECUTION: ContextVar[ExecutionLease | None] = ContextVar("trina_execution", default=None)


def ensure_execution_active() -> None:
    lease = _EXECUTION.get()
    if lease is not None:
        lease.check()


def execution_budget(timeout: float) -> float:
    ensure_execution_active()
    lease = _EXECUTION.get()
    return min(timeout, max(.001, lease.deadline - time.monotonic())) if lease else timeout


def execute_streamed(argv: list[str], *, timeout: float, cwd: str | None, env: dict[str, str] | None,
                     input_data: str | None, on_output: Callable[[str, str], None],
                     stop_event: Any = None, allow_detached_children: bool = False) -> Any:
    """受控进程出口；仅显式托管的长期会话可让子进程跨调用存活。"""
    import os
    import subprocess
    from .process_output import ProcessOutputDecoder
    from .tools.external import _terminate_background, _windows_background_job

    ensure_execution_active()
    proc = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.PIPE if input_data is not None else subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=os.name != "nt",
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0)
    native_job = None
    buffers: dict[str, list[str]] = {"stdout": [], "stderr": []}
    errors: list[Exception] = []

    def read(stream: Any, name: str) -> None:
        decoder = ProcessOutputDecoder()
        try:
            while chunk := stream.read1(4096):
                text = decoder.decode(chunk)
                if text:
                    buffers[name].append(text)
                    on_output(name, text)
            tail = decoder.decode(b"", final=True)
            if tail:
                buffers[name].append(tail)
                on_output(name, tail)
        except Exception as exc:
            errors.append(exc)
        finally:
            stream.close()

    def write() -> None:
        try:
            proc.stdin.write((input_data or "").encode("utf-8"))
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            pass
        finally:
            proc.stdin.close()

    readers: list[threading.Thread] = []
    deadline = time.monotonic() + timeout
    try:
        # Playwright 这类长期会话由上层句柄表负责 close/cancel。Windows Job 的
        # KILL_ON_JOB_CLOSE 会误杀其守护进程，因此仅该显式分支不绑定 Job。
        native_job = _windows_background_job(proc) if os.name == "nt" and not allow_detached_children else None
        readers = [threading.Thread(target=read, args=(proc.stdout, "stdout"), daemon=True),
                   threading.Thread(target=read, args=(proc.stderr, "stderr"), daemon=True)]
        for reader in readers:
            reader.start()
        if input_data is not None:
            threading.Thread(target=write, daemon=True).start()
        while proc.poll() is None:
            ensure_execution_active()
            if stop_event is not None and stop_event.is_set():
                raise RuntimeError("操作者取消了工具执行")
            if errors:
                raise errors[0]
            if time.monotonic() >= deadline:
                raise subprocess.TimeoutExpired(argv, timeout, output="".join(buffers["stdout"]), stderr="".join(buffers["stderr"]))
            try:
                proc.wait(timeout=min(.1, max(.001, deadline - time.monotonic())))
            except subprocess.TimeoutExpired:
                pass
    finally:
        if not allow_detached_children or proc.poll() is None:
            _terminate_background(proc, native_job)
        if native_job is not None:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(native_job)
        for reader in readers:
            reader.join(timeout=1)
    if errors:
        raise errors[0]
    return subprocess.CompletedProcess(argv, proc.returncode, "".join(buffers["stdout"]), "".join(buffers["stderr"]))


def reinstall_after_launcher_exit(argv: list[str]) -> None:
    """Windows 控制台启动器退出后再替换其 exe，避免 pip 遇到文件占用。"""
    import ctypes
    import os
    import subprocess
    import tempfile
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    open_process, close_handle = kernel.OpenProcess, kernel.CloseHandle
    open_process.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    open_process.restype = wintypes.HANDLE
    close_handle.argtypes = (wintypes.HANDLE,)
    launcher = open_process(0x00100000, True, os.getppid())  # SYNCHRONIZE
    if not launcher:
        raise ctypes.WinError(ctypes.get_last_error())

    helper = """import ctypes, subprocess, sys
from ctypes import wintypes

kernel = ctypes.WinDLL("kernel32")
kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
handle = int(sys.argv[1])
status = kernel.WaitForSingleObject(handle, 30_000)
kernel.CloseHandle(handle)
if status != 0:
    raise SystemExit("未能等待 Trina 启动器退出，请重试更新")
code = subprocess.call(sys.argv[2:])
if code == 0:
    print("Trina 已更新，重新运行 trina 即可使用。", flush=True)
raise SystemExit(code)
"""
    try:
        startup = subprocess.STARTUPINFO(lpAttributeList={"handle_list": [launcher]})
        subprocess.Popen([argv[0], "-c", helper, str(launcher), *argv], startupinfo=startup,
                         cwd=tempfile.gettempdir(), stdin=subprocess.DEVNULL, close_fds=True,
                         env=dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never", PYTHONIOENCODING="utf-8"))
    finally:
        close_handle(launcher)


@contextmanager
def execution_window(lease: ExecutionLease):
    lease.check()
    token = _EXECUTION.set(lease)
    try:
        yield
    finally:
        _EXECUTION.reset(token)


# ---------------------------------------------------------------------------
# 受限模式禁止清单
# ---------------------------------------------------------------------------

#: 外部工具参数级禁止（正则作用于「工具名 + 参数」拼串后的文本）
FORBIDDEN_ARGV_PATTERNS: list[tuple[str, str]] = [
    (r"--os-shell", "拿到系统 shell 属越权破坏性操作，实训场景禁止"),
    (r"--os-pwn", "sqlmap 外带 OOB 利用禁止"),
    (r"--os-smbrelay", "sqlmap SMB 中继利用禁止"),
    (r"--os-bof", "sqlmap 溢出利用禁止"),
    (r"--file-write\b", "向目标写文件禁止（外带写 shell/webshell）"),
    (r"--file-dest\b", "向目标写文件禁止"),
    (r"--sql-shell\b", "交互式 SQL shell 禁止"),
    (r"--dump-all\b", "整库导出属数据泄露，禁止"),
    (r"--dump\b.*--exclude-sysdbs", "整库导出属数据泄露，禁止"),
    (r"--risk\s*=?\s*3", "sqlmap risk=3 含破坏性 payload，禁止"),
    (r"--eval\s*=", "sqlmap --eval 可执行任意 Python，禁止"),
    (r"--crawl\b", "爬虫会超范围抓取，禁止"),
    (r"\b(mkfs|mkfs\.\w+)\b", "格式化文件系统禁止"),
    (r"\bdd\s+.*of=/dev/", "裸设备写入禁止"),
    (r":\(\)\s*\{.*\};:", "fork 炸弹禁止"),
    (r"\b(shutdown|reboot|halt|poweroff)\b", "关停主机禁止"),
    (r"\b(iptables|nft)\s+(-F|--flush)", "清空防火墙规则禁止"),
    (r"\b(hping3?|slowloris|goldeneye|t50)\b", "洪泛/DoS 工具禁止"),
    (r"nmap.*--script[= ]\S*(dos|flood|broadcast|brute)", "DoS/NSE 广播脚本禁止"),
    (r"\b(curl|wget)\b[^|;]*\|\s*(ba|z|da)?sh", "执行远端下载的脚本禁止"),
    (r">\s*/etc/", "覆盖系统配置禁止"),
    (r"\bchmod\s+(-\w+\s+)?777\s+/\s*$", "放开根目录权限禁止"),
    (r"\brm\s+-rf?\s+(/\s*$|/\*|/etc|/var|/usr|/home|/root)", "删除系统目录禁止"),
    (r"\buserdel\b|\bpasswd\s+root\b", "破坏账户凭据禁止"),
]

#: 载荷级禁止：出现在注入/上传/命令参数中的危险载荷
FORBIDDEN_PAYLOAD_PATTERNS: list[tuple[str, str]] = [
    (r"\b(DROP|TRUNCATE)\s+(TABLE|DATABASE)", "删库载荷禁止"),
    (r"\bDELETE\s+FROM\b", "批量删除数据载荷禁止"),
    (r"\bUPDATE\s+\w+\s+SET\b", "篡改数据载荷禁止"),
    (r"\b(INSERT|REPLACE)\s+INTO\s+.*\b(users|admin|mysql)\b", "篡改账户表载荷禁止"),
    (r"\bxp_cmdshell\b", "数据库命令执行禁止"),
    (r"\bINTO\s+(OUT|DUMP)FILE\b", "数据库写文件禁止"),
    (r"\bLOAD_FILE\s*\(", "读取服务器文件禁止"),
    # 注意：/etc/passwd 是 LFI 验证的标准无害取证（不含口令哈希），允许；
    # 受限模式下，真正涉及凭据的文件（shadow/sudoers/私钥）禁止读取。
    (r"/etc/shadow\b", "读取系统口令哈希禁止"),
    (r"/etc/sudoers\b", "读取提权配置禁止"),
    (r"(/root/\.ssh/|/\.ssh/id_[a-z]+)", "读取 SSH 私钥禁止"),
    (r"\brm\s+-rf\b", "删除文件载荷禁止"),
]

#: HTTP 方法策略：破坏性方法需要 exploit 级 + destructive 开关
DESTRUCTIVE_METHODS = {"DELETE", "PUT", "PATCH", "TRACE", "CONNECT"}

_FORBIDDEN_ARGV = [(re.compile(p, re.I), why) for p, why in FORBIDDEN_ARGV_PATTERNS]
_FORBIDDEN_PAYLOAD = [(re.compile(p, re.I), why) for p, why in FORBIDDEN_PAYLOAD_PATTERNS]


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Decision:
    """护栏裁决结果。`hint` 会回灌给大模型，引导它改走合规路径。"""

    allowed: bool
    reason: str = ""
    category: str = "scope"
    target: str = ""
    detail: dict[str, Any] = field(default_factory=dict)
    hint: str = ""

    def __bool__(self) -> bool:  # 允许 `if guard.check_target(...)`
        return self.allowed

    @property
    def denied(self) -> bool:
        return not self.allowed

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "category": self.category,
            "target": self.target,
            "detail": self.detail,
            "hint": self.hint,
        }


class ScopeViolation(RuntimeError):
    """护栏拒绝动作时抛出；调用方必须捕获并作为观察结果回灌给模型。"""

    def __init__(self, decision: Decision):
        super().__init__(f"[{decision.category}] {decision.reason}")
        self.decision = decision


@dataclass
class TargetInfo:
    """规范化后的目标描述。"""

    raw: str
    host: str
    port: int | None = None
    scheme: str = ""
    path: str = ""
    ips: tuple[str, ...] = ()
    is_loopback: bool = False
    is_public: bool = False
    is_cidr: bool = False

    @property
    def hostport(self) -> str:
        return f"{self.host}:{self.port}" if self.port else self.host

    def to_dict(self) -> dict[str, Any]:
        return {
            "raw": self.raw,
            "host": self.host,
            "port": self.port,
            "scheme": self.scheme,
            "path": self.path,
            "ips": list(self.ips),
            "is_loopback": self.is_loopback,
            "is_public": self.is_public,
            "is_cidr": self.is_cidr,
        }


def parse_target(raw: str) -> TargetInfo:
    """把 URL / host:port / IP / CIDR 统一成 TargetInfo。"""
    raw = (raw or "").strip()
    if not raw:
        raise ValueError("目标为空")
    scheme = ""
    path = ""
    host = raw
    port: int | None = None

    if "://" in raw:
        parts = urlsplit(raw)
        scheme = parts.scheme.lower() or "http"
        host = parts.hostname or ""
        path = parts.path or "/"
        port = parts.port or (443 if scheme == "https" else 80)
    elif "/" in raw and "-" not in raw.split("/")[0]:
        # CIDR
        return TargetInfo(raw=raw, host=raw, ips=(), is_cidr=True)
    else:
        # host[:port] 或 [v6]:port
        if raw.startswith("[") and "]" in raw:
            host, _, tail = raw.partition("]")
            host = host[1:]
            if tail.startswith(":") and tail[1:].isdigit():
                port = int(tail[1:])
        elif raw.count(":") == 1 and raw.rsplit(":", 1)[1].isdigit():
            host, port_str = raw.rsplit(":", 1)
            port = int(port_str)
    if not host:
        raise ValueError(f"无法解析目标: {raw!r}")
    return TargetInfo(raw=raw, host=host, port=port, scheme=scheme, path=path)


DEFAULT_RESOLVER = socket.getaddrinfo


def resolve_ips(host: str, resolver: Callable[..., Any] | None = None) -> tuple[str, ...]:
    """解析主机名到去重后的 IPv4/IPv6 字面量；IP 字面量直接返回。"""
    try:
        return (str(ipaddress.ip_address(host)),)
    except ValueError:
        pass
    resolver = resolver or DEFAULT_RESOLVER
    try:
        infos = resolver(host, None, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ValueError(f"DNS 解析失败 {host!r}: {exc}") from exc
    ips = sorted({str(info[4][0]) for info in infos})
    if not ips:
        raise ValueError(f"DNS 解析无结果: {host!r}")
    return tuple(ips)


# ---------------------------------------------------------------------------
# 限速
# ---------------------------------------------------------------------------


class RateLimiter:
    """令牌桶：全局 QPS + 单主机并发/速率，防止把靶机打出 DoS。"""

    def __init__(self, max_qps: float, per_host_qps: float | None = None, clock: Callable[[], float] = time.monotonic):
        self.max_qps = float(max_qps)
        self.per_host_qps = float(per_host_qps or max_qps)
        self.clock = clock
        self._tokens = float(max_qps)
        self._updated = clock()
        self._host: dict[str, tuple[float, float]] = {}
        self.waited = 0.0

    def _refill(self, bucket: float, cap: float, now: float, last: float) -> tuple[float, float]:
        elapsed = max(0.0, now - last)
        return min(cap, bucket + elapsed * cap), now

    def acquire(self, host: str = "", tokens: float = 1.0) -> float:
        """返回需要等待的秒数（并扣除令牌）。"""
        now = self.clock()
        self._tokens, self._updated = self._refill(self._tokens, self.max_qps, now, self._updated)
        bucket, last = self._host.get(host, (self.per_host_qps, now))
        bucket, _ = self._refill(bucket, self.per_host_qps, now, last)
        need = max(0.0, tokens - self._tokens, tokens - bucket)
        self._tokens = max(0.0, self._tokens - tokens)
        self._host[host] = (max(0.0, bucket - tokens), now)
        wait = need / self.max_qps if need > 0 else 0.0
        self.waited += wait
        return wait


# ---------------------------------------------------------------------------
# 护栏主体
# ---------------------------------------------------------------------------

_SAFE_CATEGORIES = ("scope", "action-level", "destructive", "forbidden", "format", "rate", "error")


class ScopeGuard:
    """授权范围守卫。所有工具的必经之路。"""

    def __init__(
        self,
        scope: ScopeConfig,
        audit: Any | None = None,
        resolver: Callable[..., Any] | None = None,
    ):
        self.scope = scope
        self.audit = audit
        self.resolver = resolver
        self.limiter = RateLimiter(scope.max_qps)
        self.stats: dict[str, int] = {"allowed": 0, "denied": 0}
        self.denials: list[Decision] = []
        self._cidrs = [ipaddress.ip_network(c, strict=False) for c in scope.authorized_cidrs]
        self._denied = [ipaddress.ip_network(c, strict=False) for c in scope.deny_cidrs]
        self._authorized_hosts = {h.lower() for h in scope.authorized_hosts}
        self._control_plane_hosts = {h.lower() for h in scope.control_plane_hosts}
        self._destructive_hosts = {h.lower() for h in scope.destructive_hosts}

    def check_workspace_path(self, raw: str, workspace: Any, runtime_root: Any, *, for_write: bool = False) -> Any:
        """解析工具路径；full 模式允许任务访问任意本地路径。"""
        from pathlib import Path
        ensure_execution_active()
        base, runs = Path(workspace).resolve(), Path(runtime_root).resolve()
        path = Path(raw).expanduser()
        if not path.is_absolute():
            local = base / path
            path = local if local.is_file() else Path.cwd() / path
        path = path.resolve()
        within = lambda child, parent: child == parent or parent in child.parents
        project_allowed = within(path, base) or within(path, Path.cwd().resolve())
        run_escape = within(path, runs) and not within(path, base)
        extra_allowed = False
        for raw_root in (() if for_write else getattr(self.scope, "allow_paths", ())):
            entry = str(raw_root).strip()
            recursive = entry.endswith("/**") or entry.endswith("\\**")
            if recursive:
                entry = entry[:-3].rstrip("/\\")
            if not entry:
                continue
            root = Path(entry).expanduser().resolve()
            if within(path, root) and (recursive or path == root or root.is_dir()):
                extra_allowed = True
                break
        # full 是 CTF/实训的默认信任模式。路径仍然要经过 resolve，避免把
        # 审计里记录的路径和实际执行路径分开；但不再把项目工作区当作硬边界。
        # restricted 保留旧的项目、任务工作区和 allow_paths 判据，供需要收紧
        # 文件范围的评测或课堂演示显式启用。
        allowed = self.scope.full_trust or ((project_allowed and not run_escape) or extra_allowed)
        decision = self._record(Decision(allowed, category="filesystem", target=str(path),
                               reason="full 信任模式允许本地路径" if self.scope.full_trust else
                               ("当前任务文件或配置的题目目录" if allowed else "文件不属于当前项目、任务或配置的题目目录")), "binary.file")
        if decision.denied:
            raise ScopeViolation(decision)
        return path

    # ---------------------------------------------------------------- 内部
    def _record(self, decision: Decision, action: str) -> Decision:
        ensure_execution_active()
        if decision.allowed:
            self.stats["allowed"] += 1
        else:
            self.stats["denied"] += 1
            self.denials.append(decision)
        if self.audit is not None:
            self.audit.append(
                "guard.allow" if decision.allowed else "guard.deny",
                decision="allow" if decision.allowed else "deny",
                category=decision.category,
                action=action,
                target=decision.target,
                reason=decision.reason,
                detail=decision.detail,
            )
        return decision

    @staticmethod
    def _deny(category: str, reason: str, target: str = "", hint: str = "", **detail: Any) -> Decision:
        if category not in _SAFE_CATEGORIES:
            category = "scope"
        return Decision(False, reason=reason, category=category, target=target, detail=detail, hint=hint)

    def _ip_allowed(self, ip: ipaddress._BaseAddress) -> tuple[bool, str]:
        """单个 IP 的判定；返回 (是否允许, 原因)。"""
        if ip.is_multicast or ip.is_unspecified or ip.is_reserved or ip.is_link_local:
            return False, f"{ip} 属特殊地址（组播/未指定/保留/链路本地）"
        if any(ip in net for net in self._denied):
            return False, f"{ip} 命中显式拒绝网段"
        if ip.is_loopback:
            if not self.scope.allow_loopback:
                return False, "回环地址被策略禁止"
            return True, "回环地址，允许（本地靶机）"
        if ip.is_private:
            return (any(ip in net for net in self._cidrs), f"{ip} 属私网地址")
        if not self.scope.allow_public:
            return False, f"{ip} 是公网地址且未开启 allow_public"
        return (any(ip in net for net in self._cidrs), f"{ip} 属公网地址")

    # ---------------------------------------------------------------- 目标
    def check_target(self, raw: str, *, action: str = "probe", port: int | None = None) -> Decision:
        """校验目标是否在授权范围内（含 DNS 解析后的每个 IP）。"""
        try:
            info = parse_target(raw)
        except ValueError as exc:
            return self._record(self._deny("format", str(exc), target=str(raw), hint="请提供 host:port 或 http(s):// 形式的合法目标"), action)

        if self.scope.full_trust:
            if info.is_cidr:
                try:
                    network = ipaddress.ip_network(info.host, strict=False)
                except ValueError as exc:
                    return self._record(self._deny("format", f"非法网段 {info.host!r}: {exc}", target=raw), action)
                return self._record(
                    Decision(True, category="scope", target=raw, reason="full 信任模式直接放行", detail={"cidr": str(network), "trust_mode": "full"}),
                    action,
                )
            ips: tuple[str, ...] = ()
            if self.scope.resolve_dns:
                try:
                    ips = resolve_ips(info.host, self.resolver)
                except ValueError:
                    # full 模式不把 DNS 预解析当作授权条件；真实连接错误由工具返回。
                    ips = ()
            return self._record(
                Decision(
                    True,
                    category="scope",
                    target=raw,
                    reason="full 信任模式直接放行",
                    detail={"ips": list(ips), "host": info.host, "port": info.port or port, "trust_mode": "full"},
                ),
                action,
            )

        if info.is_cidr:
            try:
                network = ipaddress.ip_network(info.host, strict=False)
            except ValueError as exc:
                return self._record(self._deny("format", f"非法网段 {info.host!r}: {exc}", target=raw), action)
            if not any(
                network.subnet_of(net) or network == net
                for net in self._cidrs
                if network.version == net.version
            ):
                return self._record(
                    self._deny(
                        "scope",
                        f"网段 {network} 未被整体授权",
                        target=raw,
                        hint="只能扫描授权网段的子集；请改用已授权的具体主机",
                    ),
                    action,
                )
            return self._record(Decision(True, category="scope", target=raw, detail={"cidr": str(network)}, reason="网段在授权范围内"), action)

        hostname_allowed = info.host.lower() in self._authorized_hosts
        if not self.scope.resolve_dns:
            try:
                ipaddress.ip_address(info.host)
            except ValueError:
                return self._record(
                    self._deny("format", f"{info.host} 不是 IP 字面量且 resolve_dns 已关闭", target=raw),
                    action,
                )
        try:
            ips = resolve_ips(info.host, self.resolver)
        except ValueError as exc:
            if hostname_allowed:
                ips = ()
            else:
                return self._record(
                    self._deny("scope", str(exc), target=raw, hint="请改用可达的 IP 或 host:port"), action
                )

        detail_ips: list[str] = []
        reasons: list[str] = []
        for ip_str in ips:
            ip = ipaddress.ip_address(ip_str)
            allowed, why = self._ip_allowed(ip)
            detail_ips.append(ip_str)
            reasons.append(f"{ip_str}: {why}")
            if not allowed and not hostname_allowed:
                return self._record(
                    self._deny(
                        "scope",
                        f"目标 {info.host} ({ip_str}) 不在授权范围：{why}",
                        target=raw,
                        hint="仅可测试配置文件中 authorized_cidrs / authorized_hosts 内的目标",
                        ips=detail_ips,
                    ),
                    action,
                )
            if not allowed and hostname_allowed:
                reasons[-1] += "（命中显式授权主机白名单，放行）"

        is_loopback = bool(ips) and all(ipaddress.ip_address(i).is_loopback for i in ips)
        is_public = bool(ips) and any(ipaddress.ip_address(i).is_global for i in ips)
        info.ips = ips
        info.is_loopback = is_loopback
        info.is_public = is_public
        return self._record(
            Decision(
                True,
                category="scope",
                target=raw,
                reason="目标在授权范围内",
                detail={"ips": detail_ips, "checks": reasons, "host": info.host, "port": info.port or port},
            ),
            action,
        )

    def require_target(self, raw: str, *, action: str = "probe", port: int | None = None) -> TargetInfo:
        """校验通过则返回 TargetInfo，否则抛 ScopeViolation。"""
        decision = self.check_target(raw, action=action, port=port)
        if decision.denied:
            raise ScopeViolation(decision)
        info = parse_target(raw)
        try:
            info.ips = resolve_ips(info.host, self.resolver)
        except ValueError:
            info.ips = ()
        info.is_loopback = bool(info.ips) and all(ipaddress.ip_address(i).is_loopback for i in info.ips)
        info.is_public = bool(info.ips) and any(ipaddress.ip_address(i).is_global for i in info.ips)
        return info

    def check_control_plane(self, url: str, *, method: str = "GET") -> Decision:
        """校验答题 API 控制面请求（不是靶场目标，不走目标网段判定）。

        只有显式登记在 `scope.control_plane_hosts` 的主机才可访问；方法与 scheme 也做白名单。
        控制面主机来自 `BENCHMARK_BASE_URL`，由 `trina bench` 在启动时写入并记入审计。
        """
        method = (method or "GET").upper()
        try:
            parts = urlsplit(url)
        except ValueError as exc:
            return self._record(self._deny("format", f"非法控制面 URL: {exc}", target=url), "control-plane")
        scheme = parts.scheme.lower()
        if scheme not in ("http", "https"):
            return self._record(self._deny("format", "控制面只接受 http(s):// URL", target=url), "control-plane")
        if parts.username is not None or parts.password is not None:
            return self._record(self._deny("format", "控制面 URL 不允许内嵌凭据", target=url), "control-plane")
        host = (parts.hostname or "").lower()
        if not host:
            return self._record(self._deny("format", f"控制面 URL 缺少主机: {url}", target=url), "control-plane")
        if host not in self._control_plane_hosts:
            return self._record(
                self._deny(
                    "control-plane",
                    f"主机 {host} 不在 control_plane_hosts 白名单",
                    target=url,
                    hint="答题 API 地址必须来自 BENCHMARK_BASE_URL，不能由模型指定",
                ),
                "control-plane",
            )
        if method not in ("GET", "POST"):
            return self._record(
                self._deny("control-plane", f"控制面不接受 {method} 方法", target=url),
                "control-plane",
            )
        return self._record(
            Decision(
                True,
                category="control-plane",
                target=url,
                reason="答题 API 控制面已授权",
                detail={"host": host, "method": method},
            ),
            "control-plane",
        )

    # ------------------------------------------------------------ 动作等级
    def check_action_level(self, required: str, *, target: str = "", reason: str = "") -> Decision:
        """校验动作等级是否超过配置上限。"""
        if required not in ACTION_LEVELS:
            return self._record(self._deny("format", f"未知动作等级 {required!r}", target=target), "level")
        if self.scope.full_trust:
            return self._record(
                Decision(True, category="action-level", target=target, reason=f"full 信任模式放行 {required} 动作"),
                "level",
            )
        if ACTION_LEVELS.index(required) > self.scope.level_index:
            return self._record(
                self._deny(
                    "action-level",
                    f"动作等级 {required} 超过当前上限 {self.scope.exploit_level}"
                    + (f"（{reason}）" if reason else ""),
                    target=target,
                    hint=f"当前仅允许 {self.scope.exploit_level} 级动作；如需更高等级请由授权人修改配置",
                ),
                "level",
            )
        return self._record(Decision(True, category="action-level", target=target, reason=f"等级 {required} 允许"), "level")

    def check_destructive(self, *, target: str = "", reason: str = "") -> Decision:
        """破坏性动作总闸：需 destructive=true 且目标在 destructive_hosts。"""
        if self.scope.full_trust:
            return self._record(
                Decision(True, category="destructive", target=target, reason="full 信任模式放行破坏性动作"),
                "destructive",
            )
        if not self.scope.destructive:
            return self._record(
                self._deny("destructive", "破坏性动作总开关为关闭状态", target=target, hint="改用非破坏性验证手法"),
                "destructive",
            )
        host = (parse_target(target).host.lower() if target else "")
        if not host or host not in self._destructive_hosts:
            return self._record(
                self._deny(
                    "destructive",
                    f"目标 {host or '(未指定)'} 未列入 destructive_hosts",
                    target=target,
                    hint="破坏性动作仅对显式列入 destructive_hosts 的主机开放",
                ),
                "destructive",
            )
        return self._record(Decision(True, category="destructive", target=target, reason="破坏性动作已授权"), "destructive")

    # ------------------------------------------------------------ 参数/命令
    def check_argv(self, argv: Iterable[str], *, tool: str = "", target: str = "", required_level: str = "detect") -> Decision:
        """校验外部二进制参数；禁止清单只在 restricted 模式生效。"""
        argv = [str(a) for a in argv]
        text = " ".join(argv)
        if not self.scope.full_trust:
            for pattern, why in _FORBIDDEN_ARGV:
                if pattern.search(text):
                    return self._record(
                        self._deny(
                            "forbidden",
                            f"参数命中受限模式禁止规则 {pattern.pattern!r}：{why}",
                            target=target,
                            hint="切换手法，或在明确需要时使用 full 信任模式",
                            tool=tool,
                        ),
                        "argv",
                    )
        level_decision = self.check_action_level(required_level, target=target, reason=f"工具 {tool or argv[:1]}")
        if level_decision.denied:
            return level_decision
        if target:
            target_decision = self.check_target(target, action="argv")
            if target_decision.denied:
                return target_decision
        return self._record(
            Decision(True, category="argv", target=target, reason="参数合规", detail={"tool": tool, "argv": argv[:8]}),
            "argv",
        )

    def check_payload(self, payload: str, *, target: str = "") -> Decision:
        """校验注入/上传/命令载荷中的危险模式。"""
        if self.scope.full_trust:
            return self._record(Decision(True, category="forbidden", target=target, reason="full 信任模式放行载荷"), "payload")
        for pattern, why in _FORBIDDEN_PAYLOAD:
            if pattern.search(payload or ""):
                return self._record(
                    self._deny("forbidden", f"载荷命中受限模式禁止规则 {pattern.pattern!r}：{why}", target=target, hint="切换手法，或在明确需要时使用 full 信任模式"),
                    "payload",
                )
        return self._record(Decision(True, category="forbidden", target=target, reason="载荷合规"), "payload")

    def check_http(self, url: str, *, method: str = "GET", body: str = "", required_level: str = "detect") -> Decision:
        """校验 HTTP 动作：目标范围 + 方法策略 + 载荷（URL 查询串与请求体都扫描）。"""
        method = (method or "GET").upper()
        try:
            scheme = urlsplit(url).scheme.lower()
        except ValueError as exc:
            return self._record(self._deny("format", f"非法 HTTP URL: {exc}", target=url), "http")
        if scheme not in ("http", "https"):
            return self._record(
                self._deny("format", "HTTP 出口只接受 http(s):// URL", target=url), "http"
            )
        target_decision = self.check_target(url, action=f"http.{method}")
        if target_decision.denied:
            return target_decision
        if method in DESTRUCTIVE_METHODS:
            destructive_level = self.check_action_level("exploit", target=url, reason=f"HTTP {method}")
            if destructive_level.denied:
                return destructive_level
            destructive = self.check_destructive(target=url, reason=f"{method} 请求")
            if destructive.denied:
                return destructive
        for label, blob in (
            ("query", unquote_plus(urlsplit(url).query)),
            ("body", body or ""), ("body", unquote_plus(body or "")),
        ):
            if not blob:
                continue
            payload_decision = self.check_payload(blob, target=url)
            if payload_decision.denied:
                payload_decision.detail["where"] = label
                return payload_decision
        level_decision = self.check_action_level(required_level, target=url, reason=f"HTTP {method}")
        if level_decision.denied:
            return level_decision
        return self._record(Decision(True, category="http", target=url, reason=f"{method} 合规"), "http")

    def check_http_redirect(self, source: str, destination: str) -> Decision:
        """自动跳转仅允许同源；目标本身授权不代表允许转发当前请求。"""
        try:
            before, after = urlsplit(source), urlsplit(destination)
            origins = [
                (parts.scheme.lower(), parts.hostname, parts.port or (443 if parts.scheme.lower() == "https" else 80))
                for parts in (before, after)
            ]
        except ValueError as exc:
            return self._record(self._deny("format", f"非法重定向 URL: {exc}", target=destination), "http.redirect")
        if self.scope.full_trust:
            if after.scheme.lower() not in ("http", "https") or not after.hostname:
                return self._record(self._deny("format", "重定向目标必须是 http(s) URL", target=destination), "http.redirect")
            target_decision = self.check_target(destination, action="http.redirect.target")
            if target_decision.denied:
                return target_decision
            return self._record(
                Decision(True, category="redirect", target=destination, reason="full 信任模式允许跨源重定向"),
                "http.redirect",
            )
        if origins[0] != origins[1] or after.username is not None or after.password is not None:
            return self._record(
                self._deny(
                    "redirect", "不自动跟随异源或含凭据的重定向", target=destination,
                    hint="将跳转目标作为独立检查重新提交授权控制器",
                ), "http.redirect",
            )
        return self._record(
            Decision(True, category="redirect", target=destination, reason="同源重定向，仍需逐跳校验请求"),
            "http.redirect",
        )

    # ---------------------------------------------------------------- 限速
    def throttle(self, host: str = "", tokens: float = 1.0) -> float:
        """消耗令牌并返回建议等待秒数（调用方决定是否 sleep）。"""
        ensure_execution_active()
        return self.limiter.acquire(host, tokens)

    def check_brute_scale(self, attempts: int, *, target: str = "") -> Decision:
        """爆破规模上限校验（防止把靶机打成 DoS）。"""
        if self.scope.full_trust:
            return self._record(Decision(True, category="rate", target=target, reason="full 信任模式不限制尝试规模"), "brute")
        if attempts > self.scope.max_brute_attempts:
            return self._record(
                self._deny(
                    "rate",
                    f"爆破尝试次数 {attempts} 超过上限 {self.scope.max_brute_attempts}",
                    target=target,
                    hint="缩小字典或分批进行；单次爆破不超过 max_brute_attempts",
                ),
                "brute",
            )
        return self._record(Decision(True, category="rate", target=target, reason="爆破规模合规"), "brute")

    # ---------------------------------------------------------------- 视图
    def summary(self) -> dict[str, Any]:
        return {
            "trust_mode": self.scope.trust_mode,
            "exploit_level": self.scope.exploit_level,
            "destructive": self.scope.destructive,
            "allow_public": self.scope.allow_public,
            "authorized_cidrs": list(self.scope.authorized_cidrs),
            "authorized_hosts": list(self.scope.authorized_hosts),
            "allow_paths": list(self.scope.allow_paths),
            "deny_cidrs": list(self.scope.deny_cidrs),
            "stats": dict(self.stats),
            "denials": [d.to_dict() for d in self.denials[-20:]],
        }


def is_target_in_scope(scope: ScopeConfig, raw: str) -> bool:
    """免审计的一次性判定（给 CLI/评测做预检用）。"""
    return ScopeGuard(scope).check_target(raw).allowed
