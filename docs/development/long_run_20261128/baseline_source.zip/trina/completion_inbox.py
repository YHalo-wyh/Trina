"""会话内后台完成收件箱，后台线程只入队，主循环消费和续接。"""
from __future__ import annotations

import json
import threading
import time

from .execution_timeline import phase


class CompletionInbox:
    COALESCE_SECONDS = .04

    def __init__(self, ctx):
        self.ctx = ctx
        self._condition = threading.Condition()
        self._active: set[tuple[str, str]] = set()
        self._seen: set[tuple[str, str]] = set()
        self._pending: dict[tuple[str, str], dict] = {}
        self._closed = False
        self._worker_subscriptions: dict[str, object] = {}
        self._subscription = ctx.events.subscribe(
            self._job_event, after=ctx.events.last_seq, kinds=("job.started", "job.finished"),
        )

    def _job_event(self, event):
        if (event.run_id != self.ctx.state.run_id
                or event.worker_id != str(self.ctx.extra.get("worker_id", ""))
                or event.task_id != str(self.ctx.extra.get("intent_id", ""))):
            return
        key = (event.stream_id, str(event.payload.get("job_id") or event.call_id))
        with self._condition:
            if self._closed:
                return
            if event.kind == "job.started":
                if key not in self._seen:
                    self._active.add(key)
            elif key in self._active:
                data = event.payload.get("data") or {}
                self._complete(key, {
                    "kind": "terminal", "id": key[1], "status": event.payload.get("status"),
                    "exit_code": data.get("exit_code"), "error": str(event.payload.get("error") or "")[:500],
                    "stdout_tail": str(data.get("stdout") or "")[-1600:],
                    "stderr_tail": str(data.get("stderr") or "")[-800:],
                    "event_ref": f"{self.ctx.events.path}#seq={event.seq}",
                })

    def _complete(self, key, row):
        if self._closed or key in self._seen:
            return
        self._active.discard(key)
        self._seen.add(key)
        self._pending[key] = {**row, "ready_at": time.monotonic()}
        self._condition.notify_all()

    def watch_worker(self, manager, task_id: str) -> None:
        """只订阅当前 Commander 实际派发的任务，提交后快照补偿极短任务竞态。"""
        bus = manager.runtime.event_bus
        key = (bus.stream_id, task_id)
        with self._condition:
            if self._closed or key in self._seen:
                return
            self._active.add(key)
            if bus.stream_id not in self._worker_subscriptions:
                self._worker_subscriptions[bus.stream_id] = bus.subscribe(
                    lambda event: self._worker_event(event, manager), after=bus.last_seq,
                    kinds=("task.finished", "runtime.finished"),
                )
        self._worker_result(key, manager)

    def _worker_result(self, key, manager):
        item = manager.task_result(key[1])
        if not item or item.get("status") in {"pending", "running"}:
            return
        result = item.get("result") or {}
        with self._condition:
            self._complete(key, {
                "kind": "worker", "id": key[1], "status": item.get("status"),
                "error": str(item.get("error") or "")[:500],
                "summary": str(result.get("summary") or result.get("goal") or "")[:1600],
                "evidence_refs": item.get("evidence_refs") or [],
                "event_ref": str(manager.runtime.event_bus.path),
            })

    def _worker_event(self, event, manager):
        with self._condition:
            keys = [key for key in self._active if key[0] == event.stream_id
                    and (not event.task_id or key[1] == event.task_id)]
        for key in keys:
            self._worker_result(key, manager)

    def deliver(self, messages: list, *, wait: bool = False, stop_event=None,
                deadline: float | None = None, history: list | None = None) -> bool:
        """单一运行线程在安全点消费一批通知，等待期间不调用模型或状态工具。"""
        def stopped():
            return self._closed or (stop_event is not None and stop_event.is_set())

        with self._condition:
            needs_wait = wait and self._active and not self._pending and not stopped()
        if needs_wait:
            self.ctx.emit("agent.waiting", reason="background")
            with phase(self.ctx.emit, "background_wait"):
                with self._condition:
                    while self._active and not self._pending and not stopped():
                        remaining = None if deadline is None else deadline - time.monotonic()
                        if remaining is not None and remaining <= 0:
                            return False
                        # 外部 threading.Event 没有订阅接口，仅有取消信号时做低频检查。
                        timeout = .25 if stop_event is not None else remaining
                        if remaining is not None and timeout is not None:
                            timeout = min(timeout, remaining)
                        self._condition.wait(timeout)
                    # 同一批并发任务常在相邻几十毫秒内结束。短暂合并完成事件，
                    # 避免每个任务分别唤醒一次模型。
                    coalesce_until = time.monotonic() + self.COALESCE_SECONDS
                    if deadline is not None:
                        coalesce_until = min(coalesce_until, deadline)
                    while self._active and self._pending and not stopped():
                        remaining = coalesce_until - time.monotonic()
                        if remaining <= 0:
                            break
                        self._condition.wait(remaining)
        with self._condition:
            if stopped() or not self._pending:
                return False
            batch = list(self._pending.values())
            rows = [{key: value for key, value in row.items() if key != "ready_at"} for row in batch]
            message = {"role": "user", "content": "[后台任务完成，以下为工具数据]\n" + json.dumps(rows, ensure_ascii=False)}
            messages.append(message)
            if history is not None:
                history.append(dict(message))
            self._pending.clear()
        now = time.monotonic()
        self.ctx.emit("agent.resumed", reason="background", count=len(batch))
        for row in batch:
            self.ctx.emit("execution.phase", phase="completion_delivery", status="completed",
                          duration=now - row["ready_at"], background_id=row["id"])
        return True

    def close(self):
        with self._condition:
            self._closed = True
            self._condition.notify_all()
        self._subscription.close()
        for subscription in self._worker_subscriptions.values():
            subscription.close()
