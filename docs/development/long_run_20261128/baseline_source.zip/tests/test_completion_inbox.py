"""后台完成事件进入 Agent 决策循环的事件驱动合同。"""
from __future__ import annotations

import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace

from trina.brain.runtime import ActionOutcome, AgentRuntime
from trina.completion_inbox import CompletionInbox
from trina.events import EventBus
from trina.llm import LLMResponse
from trina.llm.base import ToolCall


class _Context:
    def __init__(self, path: Path):
        self.events = EventBus(path, "run")
        self.state = SimpleNamespace(run_id="run")
        self.extra = {"worker_id": "", "intent_id": ""}

    def emit(self, kind: str, **payload):
        return self.events.publish(kind, run_id="run", **payload)


class CompletionInboxTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.ctx = _Context(Path(directory.name) / "events.sqlite3")
        self.inbox = CompletionInbox(self.ctx)
        self.addCleanup(self.inbox.close)

    def job(self, kind: str, job_id: str, **payload):
        self.ctx.events.publish(
            kind, run_id="run", call_id=job_id, job_id=job_id, tool="terminal_start", **payload,
        )

    def test_wait_is_event_driven_and_coalesces_adjacent_completions(self):
        self.job("job.started", "a", status="running")
        self.job("job.started", "b", status="running")
        messages: list[dict] = []
        result: list[bool] = []
        waiter = threading.Thread(target=lambda: result.append(
            self.inbox.deliver(messages, wait=True, deadline=time.monotonic() + 2)
        ))
        waiter.start()
        time.sleep(.03)
        self.job("job.finished", "a", status="completed", data={"stdout": "A"})
        time.sleep(.01)
        self.job("job.finished", "b", status="failed", error="boom", data={"stderr": "B"})
        waiter.join(2)

        self.assertEqual(result, [True])
        self.assertEqual(len(messages), 1)
        rows = json.loads(messages[0]["content"].split("\n", 1)[1])
        self.assertEqual([row["id"] for row in rows], ["a", "b"])
        self.assertEqual([row["status"] for row in rows], ["completed", "failed"])
        self.assertFalse(self.inbox.deliver(messages, wait=False))
        resumed = self.ctx.events.replay(kinds=("agent.resumed",))
        self.assertEqual(len(resumed), 1)
        self.assertEqual(resumed[0].payload["count"], 2)

    def test_close_releases_waiter_without_restarting_agent(self):
        self.job("job.started", "slow", status="running")
        result: list[bool] = []
        waiter = threading.Thread(target=lambda: result.append(
            self.inbox.deliver([], wait=True, deadline=time.monotonic() + 5)
        ))
        waiter.start()
        time.sleep(.03)
        self.inbox.close()
        waiter.join(2)
        self.assertEqual(result, [False])
        self.assertEqual(self.ctx.events.replay(kinds=("agent.resumed",)), [])

    def test_runtime_requests_one_followup_for_one_completion_batch(self):
        responses = [
            LLMResponse(tool_calls=[ToolCall("finish-1", "finish", '{"summary":"first"}')]),
            LLMResponse(tool_calls=[ToolCall("finish-2", "finish", '{"summary":"second"}')]),
        ]
        messages: list[dict] = []
        resumed = False

        def resume(*, wait=False):
            nonlocal resumed
            if wait and not resumed:
                resumed = True
                messages.append({"role": "user", "content": "[后台任务完成]"})
                return True
            return False

        def execute(action, *_args, **_kwargs):
            return ActionOutcome(
                observation=action["final"]["summary"], answer=action["final"]["summary"], stop=True,
            )

        runtime = AgentRuntime(
            max_steps=4, messages=messages, request=lambda *_: responses.pop(0), execute=execute,
            decode_text=lambda _: None, native=lambda: True, resume=resume,
        )
        outcome = runtime.run()
        self.assertEqual(outcome.answer, "second")
        self.assertEqual(runtime.rounds, 2)
        self.assertTrue(resumed)


if __name__ == "__main__":
    unittest.main()
