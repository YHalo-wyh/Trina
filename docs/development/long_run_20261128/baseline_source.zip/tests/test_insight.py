"""洞察层测试：假设台账、失败分类与循环守卫、证据关系图、工作台面板、新内部指标。

这些是「让 Agent 说得清为什么这么做、并且能从失败里换路」的能力，失效的话：
决策退化成撞墙循环、结论无法反向追溯、指标看不出成本效率。
"""

from __future__ import annotations

import json
import unittest
from tests.policy_fixtures import sample_policy
from pathlib import Path

from trina.board import render_board, summarise
from trina.brain.failure import LoopGuard, advice_for, alternatives_for, classify_failure
from trina.config import LLMConfig, TrinaConfig
from trina.evidence_graph import build as build_graph
from trina.eval.metrics import ScenarioResult, compute_metrics
from trina.hypotheses import HypothesisLedger
from trina.state import Finding, RunState
from trina.tools import build_registry
from trina.tools.registry import ParamSpec, Tool, ToolResult, ToolSpec


class TestHypothesisLedger(unittest.TestCase):
    def test_priority_formula(self):
        ledger = HypothesisLedger()
        item = ledger.add("怀疑 /sqli 存在错误型注入", confidence=0.8, value=0.8, info_gain=0.8, cost=0.2, risk=0.2)
        expected = (0.8 * 0.8 * 0.8) / (0.2 + 1.0 * 0.2 + 0.05)
        self.assertAlmostEqual(item.priority(), round(expected, 4), places=4)

    def test_level_words_are_coarsened(self):
        ledger = HypothesisLedger()
        item = ledger.add("假设 A", confidence="high", cost="low", risk="very low")
        self.assertEqual(item.confidence, 0.8)
        self.assertEqual(item.cost, 0.4)
        self.assertEqual(item.risk, 0.2)

    def test_duplicate_is_reused(self):
        ledger = HypothesisLedger()
        first = ledger.add("怀疑存在目录穿越，可读取系统文件")
        second = ledger.add("怀疑存在目录穿越，可读取系统文件（细化）")
        self.assertEqual(first.id, second.id)
        self.assertEqual(len(ledger.items), 1)

    def test_outcome_requires_evidence_to_confirm_or_refute(self):
        ledger = HypothesisLedger()
        confirmed = ledger.add("怀疑存在 SQL 注入")
        result = ledger.record_outcome(confirmed.id, new_information=True, confirmed=True, evidence=[{"finding_id": "PAI-001"}])
        self.assertEqual(result.status, "confirmed")
        self.assertEqual(result.priority(), 0.0, "已确认的假设不应再占用优先级")

        refuted = ledger.add("怀疑存在文件包含")
        for _ in range(3):
            ledger.record_outcome(refuted.id, new_information=False)
        self.assertEqual(refuted.status, "open", "没有新信息不能充当否定证据")
        self.assertIn("未解决", refuted.next_step)
        ledger.record_outcome(refuted.id, new_information=False, refuted=True,
                              evidence=[{"kind": "counterexample", "note": "独立验证排除了特定条件"}])
        self.assertEqual(refuted.status, "refuted")

    def test_blocked_hypothesis_is_marked(self):
        ledger = HypothesisLedger()
        item = ledger.add("怀疑可以读取 /etc/shadow")
        ledger.record_outcome(item.id, new_information=False, blocked=True)
        self.assertEqual(item.status, "blocked")
        self.assertIn("人工", item.next_step)

    def test_finalize_marks_unresolved_without_faking(self):
        ledger = HypothesisLedger()
        pending = ledger.add("怀疑存在目录爆破可发现的管理后台")
        done = ledger.add("怀疑存在 SQL 注入")
        ledger.record_outcome(done.id, new_information=True, confirmed=True, evidence=[{"finding_id": "TRINA-001"}])
        unfinished = ledger.finalize()
        self.assertEqual([item.id for item in unfinished], [pending.id])
        self.assertEqual(pending.status, "open")
        self.assertIn("下一轮", pending.next_step)
        self.assertEqual(done.status, "confirmed", "已确认的假设不应被收尾改动")

    def test_prompt_block_sorted_by_priority(self):
        ledger = HypothesisLedger()
        ledger.add("低价值假设，成本高", confidence=0.4, value=0.4, info_gain=0.4, cost=0.8, risk=0.6)
        ledger.add("高价值假设，成本低", confidence=0.9, value=0.8, info_gain=0.8, cost=0.2, risk=0.2)
        block = ledger.prompt_block()
        self.assertLess(block.index("高价值假设"), block.index("低价值假设"))

    def test_from_action_accepts_string_and_dict(self):
        ledger = HypothesisLedger()
        self.assertIsNotNone(ledger.from_action({"hypothesis": "纯文本假设"}))
        item = ledger.from_action({"hypothesis": {"statement": "结构化假设", "confidence": "high", "next_step": "验证 id 参数"}})
        self.assertIsNotNone(item)
        self.assertEqual(item.confidence, 0.8)
        self.assertEqual(item.next_step, "验证 id 参数")
        self.assertIsNone(ledger.from_action({}))


class TestFailureAndLoopGuard(unittest.TestCase):
    def _result(self, **kwargs):
        return ToolResult(**kwargs)

    def test_classify_failure_kinds(self):
        self.assertEqual(classify_failure(self._result(ok=True, summary="done")), "ok")
        self.assertEqual(classify_failure(self._result(ok=False, denied=True, error="越界")), "boundary_denied")
        self.assertEqual(classify_failure(self._result(ok=False, error="参数非法: 未知参数 ['x']")), "tool_error")
        self.assertEqual(classify_failure(self._result(ok=False, error="ConnectionError: connection refused")), "environment_error")
        self.assertEqual(classify_failure(self._result(ok=False, error="逻辑预算已用尽")), "budget_exhausted")
        self.assertEqual(classify_failure(self._result(ok=False, error="未发现任何线索", summary="未发现")), "hypothesis_error")

    def test_advice_covers_all_kinds(self):
        for kind in ("tool_error", "environment_error", "budget_exhausted", "boundary_denied", "hypothesis_error"):
            self.assertTrue(advice_for(kind), kind)

    def test_loop_guard_escalation_ladder(self):
        guard = LoopGuard()
        params = {"url": "http://127.0.0.1:9099/sqli", "param": "id"}
        result = self._result(ok=False, error="未发现", summary="未发现")
        self.assertEqual(guard.observe("sqli_test", params, result), "", "第一次不算重复")
        second = guard.observe("sqli_test", params, result)
        self.assertIn("换参数", second)
        third = guard.observe("sqli_test", params, result)
        self.assertIn("换工具", third)
        fourth = guard.observe("sqli_test", params, result)
        self.assertIn("人工", fourth)
        self.assertTrue(guard.needs_human())
        self.assertAlmostEqual(guard.redundant_rate, 3 / 4, places=4)

    def test_loop_guard_ignores_different_results(self):
        guard = LoopGuard()
        params = {"target": "127.0.0.1"}
        guard.observe("port_scan", params, self._result(ok=True, summary="发现 1 个端口", raw="80"))
        advice = guard.observe("port_scan", params, self._result(ok=True, summary="发现 2 个端口", raw="80,443"))
        self.assertEqual(advice, "", "结果不同就不算无新信息")

    def test_alternatives_for_prefers_same_category_and_lower_level(self):
        registry = build_registry()
        options = alternatives_for(registry, "poc_scan", tried={"poc_scan"})
        self.assertTrue(options)
        category = registry.get("poc_scan").spec.category
        for name in options:
            spec = registry.get(name).spec
            self.assertEqual(spec.category, category, f"{name} 应属同类能力")
            self.assertLessEqual(spec.action_level, registry.get("poc_scan").spec.action_level)
        self.assertNotIn("poc_scan", options)

    def test_alternatives_empty_for_unknown_tool(self):
        self.assertEqual(alternatives_for(build_registry(), "no_such_tool"), [])


class TestEvidenceGraph(unittest.TestCase):
    def _state(self) -> RunState:
        state = RunState(run_id="g", target="http://127.0.0.1:9099")
        host = state.host("127.0.0.1")
        host.add_port(9099, service="http", version="Apache")
        host.web_paths.append("http://127.0.0.1:9099/sqli")
        state.absorb(
            {
                "findings": [
                    {
                        "title": "SQL 注入",
                        "vuln_class": "sqli",
                        "url": "http://127.0.0.1:9099/sqli",
                        "parameter": "id",
                        "severity": "high",
                        "status": "verified",
                        "tool": "sqli_test",
                        "evidence": [{"kind": "http", "note": "报错回显"}],
                    }
                ],
                "flags": [{"value": "flag{trina_lab_x}", "source": "http://127.0.0.1:9099/flag"}],
            }
        )
        return state

    def test_build_nodes_and_edges(self):
        state = self._state()
        graph = build_graph(state, hypotheses=[{"id": "H-001", "statement": "怀疑注入", "status": "confirmed",
                                                "evidence": [{"finding_id": "TRINA-001"}]}])
        kinds = graph.node_kinds()
        self.assertGreaterEqual(kinds.get("host", 0), 1)
        self.assertGreaterEqual(kinds.get("port", 0), 1)
        self.assertEqual(kinds.get("finding"), 1)
        self.assertEqual(kinds.get("evidence"), 1)
        self.assertEqual(kinds.get("hypothesis"), 1)
        labels = [edge.label for edge in graph.edges]
        self.assertIn("证据", labels)
        self.assertIn("验证为", labels)
        self.assertIn("节点", graph.summary())

    def test_mermaid_is_renderable(self):
        graph = build_graph(self._state())
        text = graph.to_mermaid()
        self.assertTrue(text.startswith("```mermaid"))
        self.assertIn("flowchart", text)
        self.assertIn("sqli", text)
        self.assertTrue(text.strip().endswith("```"))

    def test_empty_state_still_renders(self):
        graph = build_graph(RunState(run_id="e", target="127.0.0.1"))
        self.assertIn("mermaid", graph.to_mermaid())


class TestBoard(unittest.TestCase):
    def _state_dict(self):
        return {
            "run_id": "20260101-000000-abc",
            "target": "http://127.0.0.1:9099",
            "status": "success",
            "verdict": "CONFIRMED",
            "phase": "post",
            "started_at": 1000.0,
            "ended_at": 1060.0,
            "findings": [
                {"severity": "high", "status": "verified"},
                {"severity": "info", "status": "detected"},
            ],
            "coverage": {"executed": ["sqli_probe"], "untested": [{"test_id": "lfi_probe"}], "stop_reason": ""},
            "loop": {"redundant_action_rate": 0.25},
            "hypotheses": [
                {"id": "H-001", "statement": "怀疑注入", "status": "open", "confidence": 0.7, "priority": 1.2},
                {"id": "H-002", "statement": "已确认的", "status": "confirmed", "confidence": 0.9, "priority": 0.0},
            ],
            "counters": {"steps": 6, "denied": 1, "errors": 0},
            "ledger": {"calls": 5, "input_tokens": 1200, "output_tokens": 300, "cost_usd": 0.003},
            "steps": [{"kind": "tool", "tool": "sqli_test", "ok": True, "summary": "SQL 注入已验证"}],
            "flags": [{"value": "flag{x}"}],
            "credentials": [],
            "hosts": {"127.0.0.1": {}},
            "artifacts": {"workspace": "/tmp/runs/x"},
        }

    def test_summarise_fields(self):
        data = summarise(self._state_dict())
        self.assertEqual(data["findings_total"], 2)
        self.assertEqual(data["findings_verified"], 1)
        self.assertEqual(data["hypotheses_open"], 1)
        self.assertEqual(data["redundant_rate"], 0.25)
        self.assertEqual(data["duration"], "1m00s")

    def test_render_board_sections(self):
        text = render_board(self._state_dict(), hypotheses=self._state_dict()["hypotheses"])
        for expected in ("TRINA / WORKSPACE", "研究成果", "假设台账", "覆盖", "sqli_test"):
            self.assertIn(expected, text)


class TestStateRoundTrip(unittest.TestCase):
    def test_to_dict_from_dict_round_trip(self):
        import json

        state = RunState(run_id="rt", target="http://127.0.0.1:9099", goal="验证")
        host = state.host("127.0.0.1")
        host.add_port(9099, service="http", version="Apache")
        host.alive = True
        host.web_paths.append("http://127.0.0.1:9099/sqli")
        state.absorb(
            {
                "findings": [{"title": "SQL 注入", "vuln_class": "sqli", "severity": "high", "status": "verified"}],
                "credentials": [{"target": "127.0.0.1", "service": "ssh", "username": "root", "password": "toor"}],
                "flags": [{"value": "flag{x}", "source": "http://127.0.0.1:9099/flag"}],
            }
        )
        state.verdict = "CONFIRMED"
        state.counters["denied"] = 2
        state.hypotheses = [{"id": "H-001", "statement": "怀疑注入", "status": "confirmed", "priority": 0.0}]
        state.ended_at = state.started_at + 12.5

        payload = json.loads(json.dumps(state.to_dict(), ensure_ascii=False))
        restored = RunState.from_dict(payload)

        self.assertEqual(restored.run_id, "rt")
        self.assertEqual(restored.verdict, "CONFIRMED")
        self.assertEqual(restored.counters["denied"], 2)
        self.assertEqual(list(restored.hosts["127.0.0.1"].ports.keys()), [9099], "端口键要还原成 int")
        self.assertEqual(restored.hosts["127.0.0.1"].ports[9099]["service"], "http")
        self.assertEqual(restored.hosts["127.0.0.1"].alive, True)
        self.assertEqual(len(restored.findings), 1)
        self.assertEqual(restored.findings[0].vuln_class, "sqli")
        self.assertEqual(restored.findings[0].status, "verified")
        self.assertEqual(restored.credentials[0].username, "root")
        self.assertEqual(restored.flags[0]["value"], "flag{x}")
        self.assertEqual(restored.hypotheses[0]["id"], "H-001")
        self.assertAlmostEqual(restored.ended_at, state.ended_at, places=3)
        self.assertEqual(restored.to_dict()["findings"][0]["title"], "SQL 注入")

    def test_from_dict_rejects_error_payload(self):
        with self.assertRaises(ValueError):
            RunState.from_dict({"error": "读取失败"})


class TestInsightSwitches(unittest.TestCase):
    """对照实验开关：关闭只改"模型看到什么"，度量口径必须不变（否则 A/B 不可比）。"""

    def setUp(self):
        import tempfile

        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = TrinaConfig.load()
        self.cfg.run.workspace = str(Path(self.tmp.name) / "runs")
        self.cfg.audit.dir = str(Path(self.tmp.name) / "logs")
        self.cfg.llm.max_steps = 6

    def tearDown(self):
        self.tmp.cleanup()

    def _agent(self, script: list[dict], *, ledger: bool, guard: bool):
        from trina.brain.agent import PentestAgent
        from trina.policy import AuthorizationController
        from trina.llm.replay_backend import ReplayBackend
        from trina.tools.registry import ToolRegistry

        self.cfg.run.hypothesis_ledger = ledger
        self.cfg.run.loop_guard = guard
        script_path = Path(self.tmp.name) / "goal.yaml"
        script_path.write_text(json.dumps({"steps": script}, ensure_ascii=False), encoding="utf-8")
        recorder = _RecordingBackend(
            ReplayBackend(LLMConfig(backend="replay", replay_script=str(script_path)))
        )
        agent = PentestAgent(
            self.cfg, registry=ToolRegistry([_SwitchScanTool(), _SwitchFailTool()]), backend=recorder,
            controller=AuthorizationController(sample_policy(), mode="guided")
        )
        return agent, recorder

    def test_ledger_off_hides_hypothesis_everywhere(self):
        step = {
            "response": json.dumps(
                {
                    "thought": "看看端口",
                    "action": "switch_scan",
                    "params": {"target": "127.0.0.1"},
                    "hypothesis": {"statement": "目标开放 80 端口", "confidence": "high"},
                },
                ensure_ascii=False,
            )
        }
        agent, recorder = self._agent([step, {"response": '{"thought": "完", "final": {"summary": "ok"}}'}], ledger=False, guard=True)
        state = agent.run("127.0.0.1")
        self.assertEqual(state.hypotheses, [], "关闭台账后不得登记假设")
        self.assertGreater(len(recorder.prompts), 0)
        for system, user in recorder.prompts:
            self.assertNotIn("假设台账", system + user)
            self.assertNotIn("hypothesis", system + user, "对照臂的提示词不应出现假设字段")

    def test_ledger_on_registers_hypothesis(self):
        step = {
            "response": json.dumps(
                {
                    "thought": "看看端口",
                    "action": "switch_scan",
                    "params": {"target": "127.0.0.1"},
                    "hypothesis": {"statement": "目标开放 80 端口", "confidence": "high"},
                },
                ensure_ascii=False,
            )
        }
        agent, recorder = self._agent([step, {"response": '{"thought": "完", "final": {"summary": "ok"}}'}], ledger=True, guard=True)
        state = agent.run("127.0.0.1")
        self.assertEqual(len(state.hypotheses), 1)
        self.assertTrue(
            any("假设台账" in system + user for system, user in recorder.prompts),
            "启用台账时应在提示词里展示",
        )
        # 假设必须进哈希链（state.json 可改，审计链不可改）
        audit_text = Path(state.artifacts["audit_path"]).read_text(encoding="utf-8")
        self.assertIn("目标开放 80 端口", audit_text)
        self.assertIn("H-001", audit_text)

    def test_loop_guard_off_keeps_metrics_but_silences_advice(self):
        repeat = '{"thought": "重复同一步", "action": "switch_fail", "params": {"target": "127.0.0.1"}}'
        agent, recorder = self._agent(
            [{"response": repeat} for _ in range(4)] + [{"response": '{"thought": "完", "final": {"summary": "done"}}'}],
            ledger=True,
            guard=False,
        )
        state = agent.run("127.0.0.1", max_steps=4)
        # 度量照记：冗余率与失败计数不因开关关闭而消失
        self.assertGreater(state.loop.get("redundant_action_rate", 0.0), 0.0)
        self.assertGreater(sum(v for k, v in state.counters.items() if str(k).startswith("fail_")), 0)
        self.assertEqual([note for note in state.timeline if note.get("kind") == "loop"], [])
        for _system, user in recorder.prompts:
            self.assertNotIn("与上次完全相同", user, "关闭后循环建议不得回灌给模型")


    def test_scheduler_directs_step_and_counts_miss(self):
        """集成：可绑定假设 → 下一步提示词出现调度指令；模型不遵从 → 计入 scheduler_miss。"""
        self.cfg.run.hypothesis_scheduler = True
        propose = {
            "response": json.dumps(
                {
                    "thought": "先提出可验证假设",
                    "action": "switch_scan",
                    "params": {"target": "127.0.0.1:9099"},
                    "hypothesis": {
                        "statement": "lab 的 /sqli 参数 id 存在错误型注入",
                        "vuln_class": "sqli",
                        "target": "http://127.0.0.1:9099/sqli",
                        "parameter": "id",
                        "confidence": "high",
                    },
                },
                ensure_ascii=False,
            )
        }
        ignore = '{"thought": "偏航去做别的", "action": "switch_fail", "params": {"target": "127.0.0.1:9099"}}'
        agent, recorder = self._agent(
            [propose, {"response": ignore}, {"response": '{"thought": "完", "final": {"summary": "done"}}'}],
            ledger=True, guard=True,
        )
        state = agent.run("127.0.0.1:9099", max_steps=3)

        scheduled = [user for _sys, user in recorder.prompts if "## 本步检查项" in user]
        self.assertTrue(scheduled, "本步检查项数据应进入上下文")
        self.assertIn("sqli_probe", scheduled[0])
        self.assertEqual(state.scheduler.get("missed"), 1, "模型没执行 sqli_probe → 记一次未遵从")
        self.assertEqual(state.counters.get("scheduler_miss"), 1)
        notes = [note["text"] for note in state.timeline if note.get("kind") == "scheduler"]
        self.assertTrue(any("未按调度执行" in note for note in notes), notes)
        self.assertTrue(any("调度：验证" in note for note in notes), notes)
        self.assertIn("react.schedule", Path(state.artifacts["audit_path"]).read_text(encoding="utf-8"))

    def test_scheduler_off_leaves_no_directive(self):
        self.cfg.run.hypothesis_scheduler = False
        propose = {
            "response": json.dumps(
                {
                    "thought": "提出假设",
                    "action": "switch_scan",
                    "params": {"target": "127.0.0.1"},
                    "hypothesis": {
                        "statement": "目标 127.0.0.1 的 80 端口存在 SQL 注入",
                        "vuln_class": "sqli",
                        "target": "http://127.0.0.1/sqli",
                    },
                },
                ensure_ascii=False,
            )
        }
        agent, recorder = self._agent(
            [propose, {"response": '{"thought": "完", "final": {"summary": "done"}}'}], ledger=True, guard=True,
        )
        state = agent.run("127.0.0.1", max_steps=2)
        self.assertEqual(state.scheduler, {}, "关闭调度后不应有调度统计")
        for _sys, user in recorder.prompts:
            self.assertNotIn("## 本步检查项", user)


class _RecordingBackend:
    """包一层记录提示词，用于断言"模型到底看到了什么"。"""

    def __init__(self, inner):
        self.inner = inner
        self.prompts: list[tuple[str, str]] = []

    def complete(self, system: str, user: str):
        self.prompts.append((system, user))
        return self.inner.complete(system, user)

    def __getattr__(self, item):
        return getattr(self.inner, item)


class _SwitchScanTool(Tool):
    spec = ToolSpec(
        name="switch_scan",
        summary="假端口扫描",
        category="recon",
        action_level="detect",
        params={"target": ParamSpec("str", "目标", required=True)},
    )

    def run(self, ctx, target):
        return ToolResult(
            ok=True,
            summary=f"扫描 {target}",
            facts={"ports": [{"host": target, "port": 80, "service": "http"}]},
        )


class _SwitchFailTool(Tool):
    spec = ToolSpec(
        name="switch_fail",
        summary="恒定失败的工具（用于触发循环守卫/失败分类）",
        category="vuln",
        action_level="verify",
        params={"target": ParamSpec("str", "目标", required=True)},
    )

    def run(self, ctx, target):
        return ToolResult(ok=False, error="ConnectionError: connection refused", summary="连接被拒")


class TestHypothesisScheduler(unittest.TestCase):
    """确定性调度：把台账优先级翻译成"这一步验证谁"，并记录遵从率。"""

    def setUp(self):
        from trina.policy import PolicyRegistry

        self.registry = sample_policy()
        self.tests = self.registry.tests_for("lab-http")

    def _ledger(self):
        from trina.hypotheses import HypothesisLedger

        return HypothesisLedger()

    def test_binds_registered_check_for_verifiable_hypothesis(self):
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        item = ledger.add(
            "怀疑 /sqli 的参数 id 存在错误型注入",
            confidence="high", vuln_class="sqli", target="http://127.0.0.1:9099/sqli", parameter="id",
        )
        decision = HypothesisScheduler().decide(ledger, self.tests)
        self.assertIsNotNone(decision)
        self.assertEqual(decision.hypothesis_id, item.id)
        self.assertEqual(decision.test_id, "sqli_probe")
        self.assertEqual(decision.tool, "sqli_test")
        self.assertIn("test_id", decision.prompt_block())
        prompt_data = json.loads(decision.prompt_block().split("\n", 1)[1])
        self.assertEqual(prompt_data["test_id"], decision.test_id)
        self.assertEqual(prompt_data["target"], decision.target)
        self.assertEqual(prompt_data["required"], decision.required)
        self.assertTrue(decision.matches_action(test_id="sqli_probe"))
        self.assertTrue(decision.matches_action(tool="sqli_test"))
        self.assertFalse(decision.matches_action(test_id="lfi_probe", tool="lfi_test"))

    def test_alias_normalisation_matches_vuln_class(self):
        """`SQL Injection` 这类别名要能绑定到 expect_finding=sqli 的检查项（与评分同一套归一化）。"""
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        ledger.add("别名写法", vuln_class="SQL Injection", target="http://127.0.0.1:9099/sqli")
        decision = HypothesisScheduler().decide(ledger, self.tests)
        self.assertEqual(decision.test_id, "sqli_probe")

    def test_descriptive_hypothesis_is_not_scheduled(self):
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        ledger.add("目标可能是一个 Web 站点", confidence="high")  # 无 vuln_class/target
        self.assertIsNone(HypothesisScheduler().decide(ledger, self.tests))

    def test_low_priority_is_skipped(self):
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        ledger.add(
            "低价值高成本猜测",
            confidence="low", value="low", info_gain="low", cost="high", risk="high",
            vuln_class="sqli", target="http://127.0.0.1:9099/sqli",
        )
        self.assertIsNone(HypothesisScheduler(min_priority=0.15).decide(ledger, self.tests))

    def test_tried_check_is_not_rebound(self):
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        item = ledger.add("已试过一轮", vuln_class="sqli", target="http://127.0.0.1:9099/sqli")
        item.attempts = 2
        # 同类检查项都跑过 → 没有可调度的确定性动作（交回模型提高强度，而不是重复调度同一检查项）
        self.assertIsNone(HypothesisScheduler().decide(ledger, self.tests, executed_tests={"sqli_probe"}))

    def test_unbindable_vuln_class_is_not_scheduled(self):
        """模型的 vuln_class 写成阶段名（recon）或该靶场没注册同类检查 → 不调度，避免烧 token。"""
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        ledger.add("目标有 HTTP 服务", confidence="high", vuln_class="recon", target="127.0.0.1")
        self.assertIsNone(HypothesisScheduler().decide(ledger, self.tests))

        ledger2 = self._ledger()
        ledger2.add("怀疑 XXE", confidence="high", vuln_class="xxe", target="http://127.0.0.1:9099/x")
        self.assertIsNone(HypothesisScheduler().decide(ledger2, self.tests))

    def test_goal_classes_beat_higher_priority_other_class(self):
        """任务硬性要求优先：高优先级但非目标类的假设，不得压过目标类假设。"""
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        # 优先级更高，但不是任务要求的类
        info_item = ledger.add(
            "目标可能存在敏感文件泄露",
            confidence="high", value="high", info_gain="high", cost="low", risk="low",
            vuln_class="information_disclosure", target="http://127.0.0.1:9099/.git/HEAD",
        )
        target_item = ledger.add(
            "怀疑 /sqli 参数 id 存在错误型注入",
            confidence="high", vuln_class="sqli", target="http://127.0.0.1:9099/sqli", parameter="id",
        )
        decision = HypothesisScheduler().decide(ledger, self.tests, goal_classes={"sqli"})
        self.assertEqual(decision.hypothesis_id, target_item.id)
        self.assertEqual(decision.test_id, "sqli_probe")
        self.assertIn("命中任务要求", decision.reason)

        # 目标类没有可绑定假设时，回落到台账优先级（信息泄露类：dir_enum 或 poc_scan 都算正确绑定）
        fallback = HypothesisScheduler().decide(ledger, self.tests, goal_classes={"xxe"})
        self.assertEqual(fallback.hypothesis_id, info_item.id)
        self.assertIn(fallback.test_id, {"dir_enum", "poc_scan"})

    def test_goal_directive_when_no_matching_hypothesis(self):
        """任务要求了某类验证、台账里还没有对应假设 → 直接派该类的注册检查项（目标驱动调度）。"""
        from trina.brain.scheduler import HypothesisScheduler

        scheduler = HypothesisScheduler()
        ledger = self._ledger()
        ledger.add(
            "目标可能存在敏感文件泄露",
            confidence="high", value="high", info_gain="high", cost="low", risk="low",
            vuln_class="information_disclosure", target="http://127.0.0.1:9099/.git/HEAD",
        )
        decision = scheduler.decide(ledger, self.tests, goal_classes={"lfi"})
        self.assertEqual(decision.source, "goal")
        self.assertEqual(decision.hypothesis_id, "")
        self.assertEqual(decision.test_id, "lfi_probe")
        self.assertEqual(scheduler.goal_directives, 1)
        self.assertIn("任务硬性要求", decision.prompt_block())

        # 该目标类的检查项跑过之后，不再重复派 → 回落到台账优先级
        fallback = scheduler.decide(ledger, self.tests, goal_classes={"lfi"}, executed_tests={"lfi_probe"})
        self.assertEqual(fallback.source, "hypothesis")
        self.assertIn(fallback.test_id, {"dir_enum", "poc_scan"})

    def test_compliance_counting_and_escalation(self):
        from trina.brain.scheduler import HypothesisScheduler

        ledger = self._ledger()
        ledger.add("验证对象", confidence="high", vuln_class="sqli", target="http://127.0.0.1:9099/sqli")
        scheduler = HypothesisScheduler(escalate_after=2)
        decision = scheduler.decide(ledger, self.tests)
        self.assertFalse(decision.required)
        self.assertIs(scheduler.observe(decision, test_id="dir_enum", tool="dir_bruteforce"), False)
        self.assertIs(scheduler.observe(decision, tool="poc_scan"), False)
        self.assertEqual(scheduler.missed, 2)
        self.assertEqual(scheduler.consecutive_misses, 2)
        self.assertEqual(scheduler.compliance_rate, 0.0)
        # 连续未遵从达到阈值 → 下一次调度是硬指令
        self.assertTrue(scheduler.decide(ledger, self.tests).required)
        # 遵从一次即清零
        self.assertIs(scheduler.observe(decision, test_id="sqli_probe"), True)
        self.assertEqual(scheduler.consecutive_misses, 0)
        self.assertAlmostEqual(scheduler.compliance_rate, 1 / 3, places=4)
        self.assertTrue(scheduler.to_dict()["recent"])

    def test_scheduler_directs_when_binding_exists(self):
        """有可绑定的注册检查项时，调度指令必须进提示词。"""
        from trina.brain.scheduler import HypothesisScheduler
        from trina.policy import PolicyRegistry

        ledger = self._ledger()
        ledger.add(
            "怀疑 /sqli 参数 id 存在错误型注入",
            confidence="high", vuln_class="sqli", target="http://127.0.0.1:9099/sqli", parameter="id",
        )
        decision = HypothesisScheduler().decide(ledger, sample_policy().tests_for("lab-http"))
        self.assertEqual(decision.test_id, "sqli_probe")
        self.assertIn('"test_id": "sqli_probe"', decision.prompt_block())


class TestInternalMetrics(unittest.TestCase):
    def test_cost_redundancy_and_recovery(self):
        results = [
            ScenarioResult(scenario_id="a", kind="web", status="success", duration=10, cost_usd=0.01,
                           first_evidence_seconds=2.0, redundant_rate=0.1, failures=2),
            ScenarioResult(scenario_id="b", kind="web", status="failed", duration=30, cost_usd=0.03,
                           first_evidence_seconds=None, redundant_rate=0.5, failures=3),
            ScenarioResult(scenario_id="c", kind="web", status="success", duration=20, cost_usd=0.02,
                           first_evidence_seconds=6.0, redundant_rate=0.0, failures=0),
        ]
        metrics = compute_metrics(results)
        self.assertAlmostEqual(metrics["cost_usd_total"], 0.06, places=6)
        self.assertAlmostEqual(metrics["cost_per_success"], 0.03, places=6)  # 0.06 / 2 次成功
        self.assertAlmostEqual(metrics["time_to_evidence_avg"], 4.0, places=3)  # (2+6)/2
        self.assertAlmostEqual(metrics["redundant_action_rate"], 0.2, places=4)  # (0.1+0.5+0)/3
        self.assertAlmostEqual(metrics["recovery_rate"], 1 / 2, places=4)  # 失败过且最终成功：a 与 b → 1/2

    def test_metrics_without_cost_data(self):
        metrics = compute_metrics([ScenarioResult(scenario_id="x", kind="web", status="partial", duration=1)])
        self.assertEqual(metrics["cost_per_success"], 0.0)
        self.assertIsNone(metrics["time_to_evidence_avg"])
        self.assertEqual(metrics["recovery_rate"], 0.0)


if __name__ == "__main__":
    unittest.main()
