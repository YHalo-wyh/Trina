"""RASC 首版的调度、隔离与恢复测试。"""

from __future__ import annotations

import json
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from trina.config import TrinaConfig
from trina.state import RunState
from trina.swarm import SwarmRuntime, TaskSpec, WorkerPool, default_tasks, validate_tasks


class SwarmTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.config = TrinaConfig.load().with_overrides(
            run__workspace=str(root / "runs"),
            audit__dir=str(root / "logs"),
            report__output_dir=str(root / "reports"),
        )

    def test_dag_validation_and_dedup(self) -> None:
        tasks = default_tasks("127.0.0.1", "验证目标")
        validate_tasks(tasks)
        self.assertEqual([task.id for task in tasks], ["main"])
        self.assertEqual(tasks[0].capabilities, ())
        with self.assertRaisesRegex(ValueError, "环"):
            validate_tasks([
                TaskSpec("a", "127.0.0.1", "A", depends_on=("b",)),
                TaskSpec("b", "127.0.0.1", "B", depends_on=("a",)),
            ])
        with self.assertRaisesRegex(ValueError, "等价"):
            validate_tasks([TaskSpec("a", "127.0.0.1", "A"), TaskSpec("b", "127.0.0.1", "a")])

    def test_add_task_validates_and_persists(self) -> None:
        runtime = SwarmRuntime(
            self.config,
            [TaskSpec("base", "127.0.0.1", "识别服务")],
            max_workers=1,
            executor=lambda *args: None,
        )
        self.assertFalse(runtime.add_task(TaskSpec("duplicate", "127.0.0.1", " 识别服务 ")))
        with self.assertRaisesRegex(ValueError, "无效依赖"):
            runtime.add_task(TaskSpec("bad", "127.0.0.1", "错误依赖", depends_on=("missing",)))
        self.assertTrue(runtime.add_task(TaskSpec("verify", "127.0.0.1", "验证服务", depends_on=("base",))))
        checkpoint = json.loads(runtime.checkpoint.read_text(encoding="utf-8"))
        self.assertEqual([item["id"] for item in checkpoint["tasks"]], ["base", "verify"])
        self.assertNotIn("records", checkpoint, "v4 检查点不能再保存第二份任务状态")
        self.assertEqual(checkpoint["coordination"]["intents"]["verify"]["status"], "pending")
        self.assertIs(runtime.records["verify"].__dict__, runtime.coordination.intents["verify"])

    def test_parallel_leases_reuse_and_handoff(self) -> None:
        active = 0
        maximum = 0
        lock = threading.Lock()
        first_branch = threading.Barrier(2, timeout=5)
        observed: list[tuple[str, tuple[str, ...], list[str], str]] = []

        def execute(worker, task, run_id, hints, registry):
            nonlocal active, maximum
            with lock:
                active += 1
                maximum = max(maximum, active)
            if task.id in {"recon", "web"}:
                first_branch.wait()
            with lock:
                active -= 1
            observed.append((task.id, tuple(registry.names()), hints, worker.id))
            state = RunState(run_id=run_id, target=task.target, goal=task.goal, status="success")
            state.host(task.target).technologies.append(task.id)
            state.ended_at = time.time()
            return state

        tasks = [
            TaskSpec("recon", "127.0.0.1", "识别服务", ("recon",), priority=20),
            TaskSpec("web", "127.0.0.1", "梳理 Web 面", ("web",), priority=10),
            TaskSpec("verify", "127.0.0.1", "验证目标", (), ("recon", "web")),
        ]
        runtime = SwarmRuntime(self.config, tasks, max_workers=2, executor=execute)
        summary = runtime.run()
        self.assertEqual(maximum, 2)
        self.assertEqual({item["status"] for item in summary["tasks"].values()}, {"completed"})
        self.assertEqual(summary["workers_created"], 2)
        self.assertEqual(summary["worker_reuses"], 1)
        verify = next(item for item in observed if item[0] == "verify")
        self.assertEqual(len(verify[2]), 2)
        briefs = [json.loads(item) for item in verify[2]]
        self.assertEqual({item["source_task"] for item in briefs}, {"recon", "web"})
        self.assertTrue(all(item["similarity"] >= 0.6 for item in briefs))
        self.assertTrue(all("flags" not in item["intelligence"] for item in briefs))
        self.assertEqual(
            summary["tasks"]["verify"]["result"]["facts"]["hosts"][0]["technologies"],
            ["verify"],
            "当前题目的事实图不能吸收前序 Worker 状态",
        )
        worker_result = summary["tasks"]["verify"]["result"]
        for key in ("contract_version", "verified_facts", "evidence_refs", "failed_paths", "remaining_questions", "artifacts"):
            self.assertIn(key, worker_result)
        self.assertEqual(worker_result["contract_version"], 1)
        recon = next(item for item in observed if item[0] == "recon")
        self.assertNotIn("sqli_test", recon[1])
        self.assertTrue(runtime.checkpoint.exists())
        self.assertTrue(all(Path(path).exists() for path in summary["report_paths"]))
        self.assertTrue(all(not worker.busy for worker in runtime.pool.workers))
        self.assertTrue(all(not worker.capability_lease_id for worker in runtime.pool.workers))
        self.assertTrue(all(summary["tasks"][task]["capabilities"] for task in ("recon", "web", "verify")))
        self.assertTrue(summary["tasks"]["verify"]["evidence_refs"])
        self.assertTrue(runtime.audit.verify()[0])

    def test_worker_view_exposes_frontier_and_facts_without_copying_run_state(self) -> None:
        runtime = SwarmRuntime(
            self.config,
            [TaskSpec("a", "127.0.0.1", "识别服务"),
             TaskSpec("b", "127.0.0.1", "复核服务", depends_on=("a",))],
            max_workers=1,
            executor=lambda *args: None,
        )
        runtime.coordination.facts["fact-test"] = {
            "id": "fact-test", "kind": "asset", "payload": {"host": "127.0.0.1"},
            "sources": ["a"], "evidence_refs": ["ev-1"],
        }
        view = runtime.coordination.worker_view(limit=10)
        self.assertEqual([item["id"] for item in view["ready"]], ["a"])
        self.assertEqual(view["facts"][0]["id"], "fact-test")
        self.assertEqual(view["facts"][0]["evidence_refs"], ["ev-1"])
        self.assertEqual(runtime.records["b"].status, "pending")

    def test_swarm_worker_keeps_shared_tools_on_demand_for_ctf_route(self) -> None:
        from trina.brain.agent import PentestAgent
        from trina.tools import build_registry

        agent = PentestAgent(
            self.config.with_overrides(llm__backend="replay"),
            registry=build_registry(),
            shared_context={"coordination_runtime": object(), "worker_id": "worker-1"},
        )
        # route selection is exercised by the real run setup in integration tests. The
        # shared context contract itself is covered by the registry and tool view here.
        self.assertIn("shared_context", agent.registry.names())

    def test_commander_does_not_forward_unrelated_completed_task(self) -> None:
        observed: dict[str, list[str]] = {}

        def execute(worker, task, run_id, hints, registry):
            observed[task.id] = list(hints)
            state = RunState(run_id=run_id, target=task.target, goal=task.goal, status="success")
            state.host(task.target).technologies.append(task.id)
            state.ended_at = time.time()
            return state

        tasks = [
            TaskSpec("first", "http://alpha.test", "梳理登录接口", priority=20),
            TaskSpec("second", "http://beta.test", "分析二进制加密算法", priority=10),
        ]
        runtime = SwarmRuntime(self.config, tasks, max_workers=1, executor=execute)
        runtime.run()
        self.assertEqual(observed["first"], [])
        self.assertEqual(observed["second"], [])

    def test_related_worker_receives_prior_failure_experience(self) -> None:
        observed: dict[str, list[dict]] = {}

        def execute(worker, task, run_id, hints, registry):
            if task.id == "first":
                raise RuntimeError("scanner handshake timeout")
            observed[task.id] = [json.loads(item) for item in hints]
            state = RunState(run_id=run_id, target=task.target, goal=task.goal, status="success")
            state.ended_at = time.time()
            return state

        runtime = SwarmRuntime(self.config, [
            TaskSpec("first", "http://same.test", "检查 Web 服务", priority=20),
            TaskSpec("second", "http://same.test", "复核 Web 服务", priority=10),
        ], max_workers=1, executor=execute)
        summary = runtime.run()
        self.assertEqual(summary["tasks"]["first"]["status"], "failed")
        self.assertTrue(observed["second"])
        brief = observed["second"][0]
        self.assertEqual(brief["source_status"], "failed")
        self.assertIn("scanner handshake timeout", brief["source_error"])
        self.assertTrue(brief["experience"]["failures"])
        self.assertGreaterEqual(summary["coordination"]["planner_rounds"], 2)
        self.assertIn("exploration", summary["graphs"])
        self.assertEqual(summary["tasks"]["first"]["result"]["status"], "failed")
        self.assertTrue(summary["tasks"]["first"]["result"]["failed_paths"])

    def test_new_asset_fact_generates_one_bounded_followup_intent(self) -> None:
        calls: list[str] = []

        def execute(worker, task, run_id, hints, registry):
            del worker, hints, registry
            calls.append(task.id)
            state = RunState(run_id=run_id, target=task.target, goal=task.goal, status="success")
            state.host(task.target).ports[80] = {"service": "http"}
            state.ended_at = time.time()
            return state

        runtime = SwarmRuntime(
            self.config,
            [TaskSpec("seed", "host.test", "识别服务", max_steps=4, max_seconds=30)],
            max_workers=1, executor=execute, auto_expand=True, max_generated_tasks=2,
        )
        summary = runtime.run()
        generated = [task for task in runtime.tasks if task.id.startswith("auto-")]
        self.assertEqual(len(generated), 1)
        self.assertEqual(generated[0].depends_on, ("seed",))
        self.assertIn("端口 80", generated[0].goal)
        self.assertEqual(calls, ["seed", generated[0].id])
        self.assertEqual(summary["generated_tasks"], 1)
        self.assertTrue(all(item["status"] == "completed" for item in summary["tasks"].values()))

    def test_generated_intents_obey_global_task_limit(self) -> None:
        def execute(worker, task, run_id, hints, registry):
            state = RunState(run_id=run_id, target=task.target, status="success")
            state.host(task.target).ports[80] = {"service": "http"}
            state.ended_at = time.time()
            return state

        runtime = SwarmRuntime(
            self.config,
            [TaskSpec("a", "one.test", "识别服务"), TaskSpec("b", "two.test", "识别服务")],
            max_workers=1, executor=execute, auto_expand=True, max_generated_tasks=1,
        )
        summary = runtime.run()
        self.assertEqual(summary["generated_tasks"], 1)
        self.assertEqual(len(runtime.tasks), 3)

    def test_resume_retries_only_inflight(self) -> None:
        calls: list[str] = []

        def execute(worker, task, run_id, hints, registry):
            calls.append(task.id)
            state = RunState(run_id=run_id, target=task.target, status="success")
            state.ended_at = time.time()
            return state

        tasks = [TaskSpec("a", "127.0.0.1", "A"), TaskSpec("b", "127.0.0.1", "B", depends_on=("a",))]
        runtime = SwarmRuntime(self.config, tasks, max_workers=1, executor=execute)
        runtime.records["a"].status = "completed"
        runtime.records["a"].attempt = 1
        runtime.records["b"].status = "running"
        runtime.records["b"].attempt = 1
        runtime._save()
        resumed = SwarmRuntime.resume(self.config, runtime.checkpoint, executor=execute)
        summary = resumed.run()
        self.assertEqual(calls, ["b"])
        self.assertEqual(summary["tasks"]["b"]["attempt"], 2)
        self.assertEqual(summary["tasks"]["a"]["attempt"], 1)

    def test_v3_checkpoint_records_are_migrated_into_intents(self) -> None:
        tasks = [TaskSpec("a", "127.0.0.1", "A"), TaskSpec("b", "127.0.0.1", "B", depends_on=("a",))]
        runtime = SwarmRuntime(self.config, tasks, max_workers=1, executor=lambda *args: None)
        runtime.records["a"].status, runtime.records["a"].attempt = "completed", 1
        runtime.records["b"].status, runtime.records["b"].attempt = "running", 1
        runtime._save()
        data = json.loads(runtime.checkpoint.read_text(encoding="utf-8"))
        data["version"] = 3
        data["records"] = {
            key: {name: getattr(record, name) for name in record.__dataclass_fields__}
            for key, record in runtime.records.items()
        }
        runtime.checkpoint.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        runtime.event_bus.path.unlink(missing_ok=True)
        resumed = SwarmRuntime.resume(self.config, runtime.checkpoint, executor=lambda *args: None)
        self.assertEqual(resumed.records["a"].status, "completed")
        self.assertEqual(resumed.records["b"].status, "pending")
        self.assertEqual(resumed.records["b"].attempt, 1)
        self.assertIs(resumed.records["a"].__dict__, resumed.coordination.intents["a"])

    def test_scope_preflight_preserved_in_real_agent(self) -> None:
        script = Path(self.temp.name) / "replay.json"
        script.write_text(json.dumps({"default": '{"final": {"summary": "done"}}'}), encoding="utf-8")
        config = self.config.with_overrides(
            llm__backend="replay", llm__replay_script=str(script), scope__trust_mode="restricted",
        )
        runtime = SwarmRuntime(config, [TaskSpec("blocked", "8.8.8.8", "检查目标", max_steps=1)], max_workers=1)
        summary = runtime.run()
        self.assertEqual(summary["tasks"]["blocked"]["status"], "blocked")
        self.assertEqual(summary["tasks"]["blocked"]["result"]["status"], "blocked")
        self.assertTrue(Path(summary["tasks"]["blocked"]["result"]["artifacts"]["audit_path"]).exists())

    def test_replay_agent_runs_registered_http_tool_and_writes_report(self) -> None:
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"<html><title>Trina fixture</title></html>")

            def log_message(self, format, *args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        target = f"http://127.0.0.1:{server.server_port}/"
        script = Path(self.temp.name) / "http_replay.json"
        script.write_text(json.dumps({"steps": [
            item for _ in range(2) for item in (
                {"response": json.dumps({"thought": "检查首页", "action": "http_fingerprint", "params": {"url": target}})},
                {"response": json.dumps({"thought": "完成", "final": {"summary": "首页已检查"}})},
            )
        ]}), encoding="utf-8")
        config = self.config.with_overrides(llm__backend="replay", llm__replay_script=str(script))
        runtime = SwarmRuntime(config, [
            TaskSpec("http", target, "检查首页", ("recon",), max_steps=2),
            TaskSpec("http_again", target, "复核首页", ("recon",), depends_on=("http",), max_steps=2),
        ], max_workers=1)
        summary = runtime.run()
        self.assertEqual(summary["tasks"]["http"]["status"], "completed", summary["tasks"]["http"])
        self.assertEqual(summary["tasks"]["http_again"]["status"], "completed", summary["tasks"]["http_again"])
        self.assertGreaterEqual(summary["tasks"]["http"]["result"]["counters"]["tool_calls"], 1)
        self.assertEqual(summary["tasks"]["http"]["result"]["ledger"]["calls"], 2)
        self.assertEqual(summary["tasks"]["http_again"]["result"]["ledger"]["calls"], 2)
        self.assertEqual(summary["worker_reuses"], 1)
        self.assertTrue(all(Path(path).exists() for path in summary["report_paths"]))

    def test_worker_lease_rejects_stale_release(self) -> None:
        pool = WorkerPool(self.config, 1, backend_factory=lambda _: object())
        worker = pool.acquire()
        self.assertIsNotNone(worker)
        assert worker is not None
        with self.assertRaisesRegex(RuntimeError, "租约"):
            pool.release(worker, "stale")
        pool.release(worker, worker.lease_id)

    def test_worker_exception_is_requeued_when_attempt_budget_allows(self) -> None:
        calls = 0

        def execute(worker, task, run_id, hints, registry):
            nonlocal calls
            del worker, hints, registry
            calls += 1
            if calls == 1:
                raise RuntimeError("worker process crashed")
            state = RunState(run_id=run_id, target=task.target, goal=task.goal, status="success")
            state.ended_at = time.time()
            return state

        runtime = SwarmRuntime(
            self.config,
            [TaskSpec("recover", "127.0.0.1", "恢复 Worker 任务", max_attempts=2)],
            max_workers=1,
            executor=execute,
        )
        summary = runtime.run()
        self.assertEqual(calls, 2)
        self.assertEqual(summary["tasks"]["recover"]["status"], "completed")
        self.assertEqual(summary["tasks"]["recover"]["attempt"], 2)
        self.assertTrue(any(item["event"] == "task.retry" for item in runtime.events))
        self.assertTrue(runtime.audit.verify()[0])

    def test_task_attempt_budget_must_be_positive(self) -> None:
        with self.assertRaisesRegex(ValueError, "max_attempts"):
            validate_tasks([TaskSpec("bad", "127.0.0.1", "任务", max_attempts=0)])


if __name__ == "__main__":
    unittest.main()
