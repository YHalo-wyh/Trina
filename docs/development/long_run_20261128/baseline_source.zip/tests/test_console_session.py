"""固定底栏、跨模型会话用量、思考状态及真实按键回归。"""
from __future__ import annotations

import asyncio
import io
import threading
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from trina.console_state import ConsoleState, TrackedBackend
from trina.llm.base import LLMResponse, LLMStreamEvent, LLMUsage


class ConsoleSessionTests(unittest.TestCase):
    def test_subagent_alias_and_parallel_commands_are_discoverable(self):
        from prompt_toolkit.document import Document
        from trina.console_ui import SlashCommandCompleter, command_help_sections, find_command

        self.assertEqual(find_command("/subagent").name, "subworker")
        sections = dict(command_help_sections())
        self.assertIn("/subworker", sections["并行任务"])
        self.assertIn("/repo", sections["工作区"])
        self.assertIn("/setup", sections["设置"])
        completer = SlashCommandCompleter(running=lambda: True)
        completer.recent = ["status", "queue", "tasks", "help", "jobs"]
        for query in ("/", "/sub", "/subagent"):
            with self.subTest(query=query):
                first = next(completer.get_completions(Document(query), None))
                self.assertEqual(first.display_text, "/subworker")

    def test_command_icons_are_display_only_and_fit_narrow_terminal(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from prompt_toolkit.utils import get_cwidth
        from trina.console_ui import COMMAND_ICONS, COMMAND_SYMBOLS, EnhancedConsoleInput

        for glyph in [*(icon for icon, _ in COMMAND_ICONS.values()), *COMMAND_SYMBOLS.values()]:
            self.assertEqual(get_cwidth(glyph), 1, glyph)
        enabled = True
        output = Vt100_Output(io.StringIO(), lambda: Size(rows=18, columns=34), enable_cpr=False)
        with create_pipe_input() as pipe, create_app_session(input=pipe, output=output):
            editor = EnhancedConsoleInput(status=lambda: "就绪", running=lambda: False, dynamic_values=lambda *_: (),
                                          plain=True, command_icons=lambda: enabled)
            editor.buffer.text = "/"
            editor.buffer.cursor_position = 1
            root = "".join(fragment[1] for fragment in editor._menu())
            self.assertIn("✧ /model", root)
            self.assertIn("⊙ /status", root)
            self.assertIn("▷ /play", root)
            self.assertIn("→ /run", root)
            editor.buffer.text = "/setu"
            editor.buffer.cursor_position = 5
            preview = "".join(fragment[1] for fragment in editor._menu())
            self.assertIn("⊞ /setup", preview)
            self.assertTrue(all(get_cwidth(line) == 34 for line in preview.splitlines()))
            self.assertEqual(len(preview.splitlines()), editor._menu_height())
            self.assertTrue(preview.splitlines()[-1].endswith("╯"))
            enabled = False
            self.assertNotIn("⊞", "".join(fragment[1] for fragment in editor._menu()))
            editor._accept_menu(add_space=True)
            self.assertEqual(editor.buffer.text, "/setup ")

    def test_command_icon_badges_are_aligned_and_compact_on_narrow_screens(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from prompt_toolkit.utils import get_cwidth
        from trina.console_ui import EnhancedConsoleInput

        with create_pipe_input() as pipe:
            for columns, active, inactive in (
                (72, ("class:command.badge.active", " ✧ "), ("class:command.badge.gold", " ⊞ ")),
                (26, ("class:selected class:command.icon.lilac", "✧ "), (" class:command.icon.gold", "⊞ ")),
            ):
                with self.subTest(columns=columns):
                    output = Vt100_Output(io.StringIO(), lambda: Size(rows=18, columns=columns), enable_cpr=False)
                    with create_app_session(input=pipe, output=output):
                        editor = EnhancedConsoleInput(status=lambda: "就绪", running=lambda: False,
                                                      dynamic_values=lambda *_: ())
                        editor.buffer.text = "/"
                        editor.buffer.cursor_position = 1
                        fragments = [fragment[:2] for fragment in editor._menu()]
                    self.assertIn(active, fragments)
                    self.assertIn(inactive, fragments)
                    menu = "".join(text for _, text in fragments)
                    self.assertTrue(all(get_cwidth(line) == columns for line in menu.splitlines()))

    def test_slash_menu_navigates_before_submitting_and_completes_arguments(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.console_ui import ChoiceSpec, EnhancedConsoleInput

        with create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
            editor = EnhancedConsoleInput(status=lambda: "就绪", running=lambda: False, plain=True,
                                          dynamic_values=lambda *_: [ChoiceSpec("公司 DeepSeek")])
            editor.buffer.text = "/"
            editor.buffer.cursor_position = 1
            editor._move(1)
            self.assertEqual(editor.buffer.text, "/")
            self.assertTrue(editor._complete_before_submit())
            self.assertEqual(editor.buffer.text, "/status")
            self.assertFalse(editor._complete_before_submit())

            editor.buffer.text = "/model use '公司 Dee"
            editor.buffer.cursor_position = len(editor.buffer.text)
            editor._accept_menu(add_space=True)
            self.assertEqual(editor.buffer.text, "/model use '公司 DeepSeek' ")

            editor.buffer.text = "/对话与工具"
            editor.buffer.cursor_position = len(editor.buffer.text)
            self.assertIn("/history", [item.display_text for item in editor._items()])
            editor.dismissed = True
            self.assertFalse(editor._complete_before_submit())

    def test_ctrl_space_reopens_command_menu_and_help_matches_description(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.console_ui import EnhancedConsoleInput

        with create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
            editor = EnhancedConsoleInput(status=lambda: "就绪", running=lambda: False,
                                          dynamic_values=lambda *_: (), plain=True)
            pipe.send_text("\x00help 供应商\t\r")
            self.assertEqual(editor.read(), "/help save ")

    def test_directory_shortcut_and_contextual_help_preserve_the_draft(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.console_ui import EnhancedConsoleInput

        for keys, expected in (("\x1bt", "/tools"), ("\x1bOP", "/help setup")):
            with self.subTest(command=expected), create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
                editor = EnhancedConsoleInput(status=lambda: "就绪", running=lambda: False,
                                              dynamic_values=lambda *_: (), plain=True)
                draft = "/setup footer "
                editor.buffer.text = draft
                editor.buffer.cursor_position = len(draft)
                submitted = []

                def submit(value):
                    submitted.append(value)
                    return False

                editor.app.pre_run_callables.append(
                    lambda: editor.app.loop.call_later(2, lambda: editor.app.exit(exception=TimeoutError(expected)))
                )
                pipe.send_text(keys)
                editor.run(submit)
                self.assertEqual(submitted, [expected])
                self.assertEqual(editor.buffer.text, draft)

    def test_model_directory_combines_connection_filter_and_search(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.model_picker import ModelChoice, select_model

        choices = [
            ModelChoice("first", "First", "alpha", current=True),
            ModelChoice("second", "Second", "alpha"),
            ModelChoice("second", "Second", "beta", context_window=500_000, levels=("default", "high")),
        ]
        # 两次 Tab 选中第二个连接。Alt+方向键在当前连接内筛选。
        for keys, expected in [("\t\talpha\r", choices[1]),
                               ("\t\t\x1b\x1b[Cbe\r", choices[2]),
                               ("\x1b\x1b[D\r", choices[2]),
                               ("\x1b[D\x1b[B\x1b[B\x1b[Cbta\r", choices[2]),
                               ("absent\r\x03", None)]:
            with self.subTest(keys=keys), create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
                pipe.send_text(keys)
                self.assertEqual(select_model(choices), expected)

    def test_picker_delivers_new_catalog_while_query_is_active(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.model_picker import ModelChoice, select_model

        local = ModelChoice("work", "Work", "local", current=True)
        remote = ModelChoice("work", "Work", "remote-only")
        async def discover(force):
            pipe.send_text("rmtonly")
            await asyncio.sleep(.04)
            yield [local, remote], ""
            pipe.send_text("\r")
        with create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
            self.assertEqual(select_model([local], discover=discover), remote)

    def test_drag_model_scrollbar_to_end_then_confirm(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from trina import console_ui
        from trina.model_picker import ModelChoice, select_model
        from trina.scrollbar import ScrollbarControl

        choices = [ModelChoice("test", "test", f"model-{n}") for n in range(100)]
        factory = console_ui._panel_app
        def panel(*args, **kwargs):
            app = factory(*args, **kwargs)
            def send_drag(_):
                app.after_render -= send_drag
                info = next(w.render_info for w in app.layout.visible_windows if isinstance(w.content, ScrollbarControl))
                x, top = info._x_offset + 1, info._y_offset + 1
                bottom = top + info.window_height - 1
                pipe.send_text(f"\x1b[<0;{x};{top}M\x1b[<32;{x};{bottom}M\x1b[<0;{x};{bottom}m\r")
            app.after_render += send_drag
            return app

        output = Vt100_Output(io.StringIO(), lambda: Size(rows=18, columns=90), enable_cpr=False)
        with create_pipe_input() as pipe, create_app_session(input=pipe, output=output), patch.object(console_ui, "_panel_app", panel):
            self.assertIn(select_model(choices), choices[-10:])

    def test_suspended_main_input_does_not_consume_modal_keys(self):
        from trina.console_ui import _ModalInput
        source = SimpleNamespace(read_keys=lambda: ["enter"], flush_keys=lambda: ["escape"])
        app = SimpleNamespace(_running_in_terminal=True)
        proxy = _ModalInput(source, app)
        self.assertEqual(proxy.read_keys(), [])
        self.assertEqual(proxy.flush_keys(), [])
        app._running_in_terminal = False
        self.assertEqual(proxy.read_keys(), ["enter"])
        self.assertEqual(proxy.flush_keys(), ["escape"])

    def test_session_accumulates_across_backends_and_resets_without_reusing_their_ledgers(self):
        view = ConsoleState()
        for incoming, outgoing, cached in ((1000, 200, 600), (500, 100, 300)):
            backend = SimpleNamespace(complete=lambda *_, i=incoming, o=outgoing, c=cached:
                LLMResponse(text="answer", usage=LLMUsage(input_tokens=i, output_tokens=o, cache_read_tokens=c)))
            TrackedBackend(backend, view).complete("s", "u")
        data = view.usage_data()
        self.assertEqual((data["calls"], data["total_tokens"]), (2, 1800))
        self.assertEqual(view.context_tokens, 500)
        self.assertEqual(data["cache_hit_rate"], .6)
        self.assertIn("60.0%", view.footer(88))
        view.reset()
        self.assertEqual(view.usage_data()["calls"], 0)
        self.assertEqual(view.usage_data()["total_tokens"], 0)
        self.assertEqual(view.footer(88), "")

    def test_missing_usage_is_not_zero_percent_and_partial_rates_use_only_known_input(self):
        view = ConsoleState()
        view.model_finished(LLMUsage(input_tokens=1000, output_tokens=100))
        self.assertNotIn("缓存命中", view.footer(88))
        self.assertNotIn("未提供", view.footer(88))
        view.model_finished(LLMUsage(input_tokens=100, cache_read_tokens=80))
        self.assertAlmostEqual(view.usage_data()["cache_hit_rate"], .8)
        self.assertIn("80.0%（部分）", view.footer(88))
        view.model_finished(None)
        self.assertIn("≥", view.footer(88))
        empty = ConsoleState()
        empty.model_finished(LLMUsage())
        self.assertEqual(empty.footer(88), "")
        view.model_finished(LLMUsage(input_tokens=10, cost=.1))
        self.assertIn("费用 ≥$0.1000", view.footer(120))

    def test_footer_before_any_call_is_hidden(self):
        self.assertEqual(ConsoleState().footer(88), "")

    def test_individual_missing_fields_are_not_rendered_as_zero(self):
        input_only = ConsoleState()
        input_only.model_finished(LLMUsage(input_tokens=25, input_reported=True))
        self.assertIn("入 25", input_only.footer(88))
        self.assertNotIn("出", input_only.footer(88))
        self.assertNotIn("未提供", input_only.footer(88))
        cache_write_only = ConsoleState()
        cache_write_only.model_finished(LLMUsage(input_tokens=25, cache_write_tokens=5,
                                                 input_reported=True, cache_write_reported=True))
        footer = cache_write_only.footer(100)
        self.assertNotIn("缓存命中", footer)
        self.assertIn("缓存写 5", footer)
        self.assertNotIn("缓存读", footer)
        self.assertNotIn("未提供", footer)

    def test_request_phase_covers_real_wait_and_recovers_after_an_exception(self):
        view = ConsoleState()
        entered, release = threading.Event(), threading.Event()
        def complete(*_):
            entered.set()
            release.wait(2)
            return LLMResponse(text="answer", usage=LLMUsage(input_tokens=10))
        backend = TrackedBackend(SimpleNamespace(complete=complete), view)
        worker = threading.Thread(target=lambda: backend.complete("s", "u"))
        worker.start()
        self.assertTrue(entered.wait(1))
        self.assertEqual(view.activity()[0], "waiting")
        release.set()
        worker.join(2)
        self.assertEqual(view.activity()[0], "processing")
        failed = TrackedBackend(SimpleNamespace(complete=lambda *_: (_ for _ in ()).throw(ValueError("failure"))), view)
        with self.assertRaises(ValueError):
            failed.complete("s", "u")
        self.assertNotEqual(view.activity()[0], "thinking")
        self.assertEqual(view.pending, 0)
        self.assertEqual(view.usage_data()["calls"], 2)

    def test_stream_activity_distinguishes_waiting_reasoning_and_reply(self):
        view, seen, phases = ConsoleState(), [], []
        def complete(_messages, **options):
            phases.append(view.activity()[0])
            for kind in ("start", "thinking_delta", "text_delta"):
                options["on_event"](LLMStreamEvent(kind, delta="内容"))
                phases.append(view.activity()[0])
            return LLMResponse(text="回答")
        backend = TrackedBackend(SimpleNamespace(complete_messages=complete), view)
        backend.complete_messages([{"role": "user", "content": "你好"}], on_event=seen.append)
        self.assertEqual(phases, ["waiting", "waiting", "thinking", "responding"])
        self.assertEqual([event.type for event in seen], ["start", "thinking_delta", "text_delta"])
        self.assertEqual(view.pending, 0)
        self.assertEqual(view.usage_data()["calls"], 1)

    def test_usage_fits_narrow_and_short_terminals(self):
        from rich.cells import cell_len
        view = ConsoleState()
        view.model_finished(LLMUsage(input_tokens=1234567, output_tokens=100200, cache_read_tokens=1000000,
                                    cache_write_tokens=20000, cost=.0123))
        for width in (20, 40, 88, 120):
            for compact in (False, True):
                self.assertLessEqual(max(cell_len(line) for line in view.footer(width, compact).splitlines()), width)
                self.assertIn("缓存命中", view.footer(width, compact))

    def test_reply_has_no_automatic_digest_and_thought_summary_has_a_separate_style(self):
        from trina.terminal import render_answer, render_process, clean_text
        answer = render_answer("## 结果\n\n完成。\n\n```python\nprint('ok')\n```", width=60, color=True)
        self.assertNotIn("[Trina] 输出", clean_text(answer))
        self.assertIn("完成。", clean_text(answer))
        for unwanted in ("会话 chat-", "轮次", "目标 未指定", "假设 待验证"):
            self.assertNotIn(unwanted, answer)
        process = render_process("检查返回的登录状态", label="思考摘要", width=40, color=True)
        self.assertIn("思考摘要", clean_text(process))
        self.assertNotIn("┊", clean_text(process))
        self.assertNotIn("[Trina] 输出", process)

    def test_bottom_stays_fixed_during_output_and_enter_keeps_the_application_alive(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from trina.console_ui import EnhancedConsoleInput
        for columns, rows in ((88, 24), (40, 20), (20, 12)):
            with self.subTest(columns=columns, rows=rows):
                stream, frames, submitted = io.StringIO(), [], []
                output = Vt100_Output(stream, lambda: Size(rows=rows, columns=columns), enable_cpr=False)
                view = ConsoleState()
                view.model_finished(LLMUsage(input_tokens=100, output_tokens=20, cache_read_tokens=60))
                with create_pipe_input() as pipe, create_app_session(input=pipe, output=output):
                    editor = EnhancedConsoleInput(status=lambda: "ready", running=lambda: True,
                        dynamic_values=lambda *_: (), usage=view.footer, activity=lambda: ("thinking", "思考中", 1), plain=True)
                    started = False
                    async def exercise():
                        try:
                            await asyncio.sleep(.05)
                            editor.buffer.text = "继续"
                            editor.write("\n".join(f"output {i}" for i in range(80)))
                            await asyncio.sleep(.25)
                            self.assertEqual(editor.buffer.text, "继续")
                            pipe.send_text("\r")
                            await asyncio.sleep(.15)
                            self.assertTrue(editor.app.is_running)
                            pipe.send_text("/invalid\r")
                            await asyncio.sleep(.1)
                            self.assertTrue(editor.app.is_running)
                            pipe.send_text("/quit\r")
                        except BaseException as exc:
                            if editor.app.is_running:
                                editor.app.exit(exception=exc)
                    def rendered(app):
                        nonlocal started
                        if not app.is_done:
                            screen = app.renderer.last_rendered_screen
                            lines = ["".join(screen.data_buffer[y][x].char for x in range(columns)) for y in range(rows)]
                            frames.append(lines)
                        if not started:
                            started = True
                            app.create_background_task(exercise())
                    editor.app.after_render += rendered
                    def submit(value):
                        submitted.append(value)
                        if value == "/invalid":
                            raise SystemExit(2)
                        return value != "/quit"
                    editor.run(submit)
                self.assertEqual(submitted, ["继续", "/invalid", "/quit"])
                self.assertGreaterEqual(len(frames), 2)
                footer_positions = []
                for lines in frames:
                    matches = [i for i, line in enumerate(lines) if "会话 Token" in line or "缓存命中" in line]
                    if matches:
                        footer_positions.append(matches[0])
                        self.assertTrue(any("缓存命中" in line for line in lines[matches[0]:]))
                self.assertTrue(footer_positions, frames)
                self.assertEqual(len(set(footer_positions)), 1)
                self.assertIn("\x1b[?1049h", stream.getvalue())
                self.assertIn("\x1b[?1049l", stream.getvalue())

    def test_startup_update_banner_leaves_input_responsive(self):
        import tempfile
        from pathlib import Path
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from trina.config import TrinaConfig
        from trina.console_ui import EnhancedConsoleInput
        from trina.interactive import Console

        release = threading.Event()
        release_tag = "v9.8.7"
        stream = io.StringIO()
        output = Vt100_Output(stream, lambda: Size(rows=18, columns=66), enable_cpr=False)

        def check_release():
            if release.wait(5):
                return release_tag, "trina update"
            return None

        def make_editor(**kwargs):
            editor = EnhancedConsoleInput(**kwargs)

            async def until(predicate, message):
                for _ in range(200):
                    if predicate():
                        return
                    await asyncio.sleep(.01)
                self.fail(message)

            async def exercise():
                try:
                    pipe.send_text("draft")
                    await until(lambda: editor.buffer.text == "draft", "检查期间应能输入")
                    self.assertIsNone(editor._update_notice)
                    release.set()
                    await until(lambda: release_tag in stream.getvalue(), "发现新版后应显示更新提示")
                    screen = editor.app.renderer.last_rendered_screen
                    top_line = "".join(screen.data_buffer[0][x].char for x in range(66))
                    self.assertIn(release_tag, top_line)
                    self.assertIn("trina update", top_line)
                    self.assertEqual(editor.buffer.text, "draft")
                    editor.buffer.reset()
                    pipe.send_text("/quit\r")
                except Exception as exc:
                    editor.app.exit(exception=exc)
                finally:
                    release.set()

            editor.app.pre_run_callables.append(lambda: editor.app.create_background_task(exercise()))
            return editor

        with tempfile.TemporaryDirectory() as directory, create_pipe_input() as pipe, \
             create_app_session(input=pipe, output=output), \
             patch.dict("os.environ", {"TRINA_TASKS_FILE": str(Path(directory) / "tasks.json")}), \
             patch("trina.interactive.enhanced_input_available", return_value=True), \
             patch("trina.interactive.EnhancedConsoleInput", side_effect=make_editor), \
             patch("trina.updater.check_release", side_effect=check_release) as check:
            self.assertEqual(Console(TrinaConfig(), plain=True).run(), 0)
        check.assert_called_once_with()

    def test_running_console_opens_subworker_and_ctrl_c_stops_before_exit(self):
        import tempfile
        from pathlib import Path
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from trina.config import TrinaConfig
        from trina.console_ui import EnhancedConsoleInput
        from trina.interactive import Console

        stream = io.StringIO()
        output = Vt100_Output(stream, lambda: Size(rows=12, columns=44), enable_cpr=False)
        with tempfile.TemporaryDirectory() as directory, patch.dict(
            "os.environ", {"TRINA_TASKS_FILE": str(Path(directory) / "tasks.json")},
        ), create_pipe_input() as pipe, create_app_session(input=pipe, output=output):
            console = Console(TrinaConfig.load(), plain=True)
            # 保持任务在停止后的收尾阶段，验证第二次按键可以直接退出。
            console.session.thread = SimpleNamespace(is_alive=lambda: True)
            tasks = {"revision": 1, "counts": {"pending": 8}, "tasks": [
                {"status": "pending", "text": f"Task {index}"} for index in range(8)
            ]}
            editor = EnhancedConsoleInput(
                status=console._prompt_status, running=lambda: console.session.running,
                dynamic_values=console._completion_values, plain=True, motion="none",
                tasks=lambda: tasks,
            )
            console.output = editor.write
            interrupt_frame = 0

            async def until(predicate, description):
                for _ in range(200):
                    if predicate():
                        return
                    await asyncio.sleep(.01)
                self.fail(description)

            async def exercise():
                nonlocal interrupt_frame
                try:
                    pipe.send_text("/")
                    await until(lambda: "/subworker" in stream.getvalue(), "运行中菜单首屏应显示 /subworker")
                    pipe.send_text("\r\r")
                    await until(lambda: "SUBWORKERS" in stream.getvalue(), "运行中应能打开 Worker 面板")
                    pipe.send_text("\x1b")
                    await until(lambda: not editor.app._running_in_terminal, "应能返回主会话")
                    editor.buffer.text = "保留草稿"
                    interrupt_frame = stream.tell()
                    pipe.send_text("\x03")
                    await until(console.session.stop_event.is_set, "第一次 Ctrl+C 应向当前任务发送停止信号")
                    self.assertTrue(editor.app.is_running)
                    self.assertFalse(editor.app.is_done)
                    self.assertNotIn("\x1b[?1049l", stream.getvalue()[interrupt_frame:])
                    self.assertEqual(editor.buffer.text, "保留草稿")
                    pipe.send_text("\x03")
                    await until(lambda: editor.app.is_done, "第二次 Ctrl+C 应退出")
                except Exception as exc:
                    editor.app.exit(exception=exc)

            editor.app.pre_run_callables.append(lambda: editor.app.create_background_task(exercise()))
            with patch("trina.interactive.enhanced_input_available", return_value=True):
                editor.run(console.handle)
            self.assertTrue(console.session.stop_event.is_set())
            self.assertIn("\x1b[?1049l", stream.getvalue()[interrupt_frame:])

    def test_real_console_keeps_draft_usage_and_footer_when_model_dialog_returns(self):
        import tempfile
        from pathlib import Path
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from trina.config import TrinaConfig
        from trina import console_ui
        from trina.console_ui import EnhancedConsoleInput
        from trina.interactive import Console
        from trina.providers import ProfileStore, ProviderProfile
        from trina.tools import build_registry
        entered, release, model_opened, settings_opened = (threading.Event() for _ in range(4))
        def complete(*_):
            entered.set()
            release.wait(3)
            return LLMResponse(text="正式回答", usage=LLMUsage(input_tokens=100, output_tokens=20, cache_read_tokens=60))
        factory = console_ui._panel_app
        def panel(*args, **kwargs):
            from prompt_toolkit.application.current import get_app
            parent_loop = get_app().loop
            app = factory(*args, **kwargs)
            def ready(_):
                self.assertIs(app.loop, parent_loop, "嵌套面板必须复用主 UI 事件循环")
                (settings_opened if args[1] == "模型设置" else model_opened).set()
            app.after_render += ready
            return app
        stream = io.StringIO()
        size = [Size(rows=26, columns=88)]
        output = Vt100_Output(stream, lambda: size[0], enable_cpr=False)
        with tempfile.TemporaryDirectory() as directory, patch.dict("os.environ", {"TRINA_PROVIDERS_FILE": str(Path(directory) / "providers.json")}):
            store = ProfileStore()
            store.profiles = {name: ProviderProfile(name, "deepseek", "https://api.deepseek.com/v1", "deepseek-chat", api_key=f"test-{name}-private")
                              for name in ("primary", "secondary")}
            store.active = "primary"
            store.save()
            config = TrinaConfig.load().with_overrides(policy__mode="free", run__workspace=str(Path(directory) / "runs"), audit__dir=str(Path(directory) / "logs"))
            console = Console(config, backend=SimpleNamespace(complete=complete), registry=build_registry(), plain=True, autostart_lab=False)
            with create_pipe_input() as pipe, create_app_session(input=pipe, output=output):
                def editor_factory(**kwargs):
                    editor = EnhancedConsoleInput(**kwargs)
                    started = False
                    async def until(predicate):
                        for _ in range(1000):
                            if predicate():
                                return
                            await asyncio.sleep(.01)
                        raise AssertionError("UI operation timed out: " + "".join(editor._chunks)[-800:])
                    async def exercise():
                        try:
                            await asyncio.sleep(.05)
                            pipe.send_text("hello\r")
                            await until(entered.is_set)
                            self.assertEqual(console._activity()[0], "waiting")
                            self.assertEqual(console._footer_context().task, "hello")
                            self.assertEqual(console._footer_context().directory, str(Path.cwd()))
                            editor.buffer.text = "保留未发送补充"
                            release.set()
                            await until(lambda: not console.session.running)
                            self.assertEqual(editor.buffer.text, "保留未发送补充")
                            self.assertEqual(console.view.usage_data()["total_tokens"], 120)
                            self.assertIn("正式回答", "".join(editor._chunks))
                            self.assertNotIn("轮次", "".join(editor._chunks))
                            self.assertNotIn("目标 未指定", "".join(editor._chunks))
                            pipe.send_text("\x1bp")
                            await until(model_opened.is_set)
                            self.assertIn("●", stream.getvalue())
                            self.assertIn("secondary", stream.getvalue())
                            pipe.send_text("secondary reasoner\r")
                            await until(lambda: console.config.llm.model == "deepseek-reasoner")
                            await until(lambda: not editor.app._running_in_terminal)
                            self.assertTrue(editor.app.is_running)
                            self.assertEqual(editor.buffer.text, "保留未发送补充")
                            self.assertEqual(ProfileStore().active, "secondary")
                            self.assertNotIn("test-secondary-private", stream.getvalue())
                            self.assertEqual(console.view.usage_data()["total_tokens"], 120)
                            editor.buffer.reset()
                            model_opened.clear()
                            size[0] = Size(rows=12, columns=38)
                            pipe.send_text("/models\r")
                            await until(model_opened.is_set)
                            self.assertIn("F1", stream.getvalue())
                            pipe.send_text("\x1b")
                            await until(lambda: not editor.app._running_in_terminal)
                            self.assertEqual(ProfileStore().active, "secondary")
                            size[0] = Size(rows=26, columns=88)
                            model_opened.clear()
                            pipe.send_text("/model\r")
                            await until(model_opened.is_set)
                            pipe.send_text("\x1bOQ")
                            await until(settings_opened.is_set)
                            pipe.send_text("\x1b")
                            await until(lambda: not editor.app._running_in_terminal)
                            pipe.send_text("/new\r")
                            await until(lambda: console.view.usage_data()["calls"] == 0)
                            self.assertEqual(console._footer_context().task, "新对话")
                            pipe.send_text("/quit\r")
                        except BaseException as exc:
                            release.set()
                            pipe.send_text("\x03")
                            if editor.app.is_running:
                                editor.app.exit(exception=exc)
                    def rendered(app):
                        nonlocal started
                        if not started:
                            started = True
                            app.create_background_task(exercise())
                    editor.app.after_render += rendered
                    return editor
                with patch("trina.llm.openai_backend.OpenAICompatBackend.remote_catalog", side_effect=ValueError("offline")), patch("trina.interactive.enhanced_input_available", return_value=True), patch("trina.interactive.EnhancedConsoleInput", side_effect=editor_factory), patch("trina.console_ui._panel_app", side_effect=panel), patch("trina.updater.check_release", return_value=None):
                    self.assertEqual(console.run(), 0)

    def test_thinking_marker_moves_but_idle_does_not(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output import DummyOutput
        from trina.console_ui import EnhancedConsoleInput
        phase = ["thinking"]
        with create_pipe_input() as pipe, create_app_session(input=pipe, output=DummyOutput()):
            editor = EnhancedConsoleInput(status=lambda: "ready", running=lambda: True,
                dynamic_values=lambda *_: (), activity=lambda: (phase[0], "state", 1))
            with patch("trina.console_ui.time.monotonic", return_value=0):
                first = editor._activity()
            with patch("trina.console_ui.time.monotonic", return_value=.5):
                second = editor._activity()
            self.assertNotEqual(first, second)
            phase[0] = "idle"
            with patch("trina.console_ui.time.monotonic", return_value=.25):
                self.assertEqual(editor._activity(), editor._activity())


    def test_context_footer_keeps_model_directory_task_and_draft_at_different_widths(self):
        from prompt_toolkit.application.current import create_app_session
        from prompt_toolkit.data_structures import Size
        from prompt_toolkit.input import create_pipe_input
        from prompt_toolkit.output.vt100 import Vt100_Output
        from rich.cells import cell_len
        from trina.console_state import ConsoleContext
        from trina.console_ui import EnhancedConsoleInput
        for columns in (170, 88, 40, 20):
            with self.subTest(columns=columns):
                frames, stream = [], io.StringIO()
                context = [ConsoleContext("运行中", "DeepSeek V4.1 Flash Max",
                                          "C:/Users/WYH/Desktop/网安实训中级", "修复会话日志",
                                          "步骤 3/12", 125_000, 500_000)]
                output = Vt100_Output(stream, lambda: Size(rows=30, columns=columns), enable_cpr=False)
                with create_pipe_input() as pipe, create_app_session(input=pipe, output=output):
                    editor = EnhancedConsoleInput(status=lambda: "running", running=lambda: True,
                        dynamic_values=lambda *_: (), activity=lambda: ("thinking", "思考中", 20),
                        context=lambda: context[0], plain=True)
                    self.assertLessEqual(editor.app.ttimeoutlen, .05)
                    self.assertLessEqual(editor.app.timeoutlen, .1)
                    editor.buffer.text = "保留草稿"
                    started = False
                    async def exercise():
                        try:
                            await asyncio.sleep(.08)
                            context[0] = ConsoleContext("运行中", "GPT-5.2 High", context[0].directory,
                                                        "检查事件流", "步骤 4/12", 150_000, 500_000)
                            editor.write("事件输出")
                            await asyncio.sleep(.12)
                            self.assertEqual(editor.buffer.text, "保留草稿")
                            footer = "".join(text for _, text in editor._status())
                            rail = "".join(text for _, text in editor._rail())
                            activity = "".join(text for _, text in editor._activity())
                            self.assertNotIn("\n", activity)
                            self.assertEqual(editor._activity_height(), 1)
                            self.assertEqual(editor._menu_height(), 0)
                            self.assertLessEqual(max(cell_len(line) for line in footer.splitlines()), columns)
                            self.assertLessEqual(cell_len(rail), columns)
                            self.assertLessEqual(max(cell_len(line) for line in activity.splitlines()), columns)
                            editor.app.exit()
                        except BaseException as exc:
                            editor.app.exit(exception=exc)
                    def rendered(app):
                        nonlocal started
                        if not app.is_done:
                            screen = app.renderer.last_rendered_screen
                            frames.append("\n".join("".join(screen.data_buffer[y][x].char for x in range(columns)) for y in range(30)))
                        if not started:
                            started = True
                            app.create_background_task(exercise())
                    editor.app.after_render += rendered
                    editor.run(lambda _: True)
                visible = "\n".join(frames)
                for expected in (("DeepSeek", "GPT-5.2 High") if columns >= 40 else ("DeepSe", "GPT-5")) + ("📁", "网安实训中级",
                                 "修复会话日志" if columns >= 40 else "修复…",
                                 "检查事件流" if columns >= 40 else "检查…"):
                    self.assertIn(expected, visible)
                self.assertNotIn("Enter 发送补充", visible)
                self.assertNotIn("已上翻历史", visible)

    def test_footer_role_starts_flush_left(self):
        from trina.console_state import ConsoleContext

        footer = ConsoleContext("运行中", "model", "/workspace", "任务").footer(80)
        self.assertEqual(footer[0], ("class:context.role", "Commander"))
        self.assertTrue("".join(value for _, value in footer).startswith("Commander"))

    def test_rail_shows_task_total_duration(self):
        from trina.console_state import ConsoleContext

        context = ConsoleContext("运行中", "model", "/workspace", "任务", duration_seconds=125)
        text = "".join(value for _, value in context.rail(88))
        self.assertIn("⏱ 2m05s", text)
        plain = ConsoleContext("运行中", "model", "/workspace", "任务")
        self.assertNotIn("⏱", "".join(value for _, value in plain.rail(88)))

    def test_context_meter_is_left_aligned_and_directory_stays_right(self):
        from trina.console_state import ConsoleContext, _cells

        context = ConsoleContext("运行中", "model", "C:/workspace/project", "任务",
                                 context_tokens=25_000, context_window=500_000)
        rail = context.rail(88)
        text = "".join(value for _, value in rail)
        self.assertTrue(text.startswith("◔ 5%"), text)
        self.assertTrue(text.endswith("C:/workspace/project"), text)
        self.assertEqual(_cells(text), 88)

    def test_session_title_contract_uses_short_goal_and_safe_fallback(self):
        from trina.session_title import fallback_session_title, generate_session_title, parse_generated_title

        self.assertEqual(parse_generated_title("<title>修复损坏的会话日志</title>"), "修复损坏的会话日志")
        self.assertIsNone(parse_generated_title("解释文字，没有标记"))
        self.assertIsNone(parse_generated_title("<title/>"))
        self.assertEqual(fallback_session_title("你好"), "新对话")
        fallback = fallback_session_title("请帮我修复 corrupt session log。然后补回归测试")
        self.assertEqual(fallback, "修复 corrupt session log")
        self.assertLessEqual(len(fallback), 32)
        requests = []
        backend = SimpleNamespace(complete_messages=lambda messages, **kwargs:
                                  requests.append((messages, kwargs)) or
                                  LLMResponse(text="<title>修复损坏的会话日志</title>"))
        title, response = generate_session_title("修复损坏的会话日志", backend)
        self.assertEqual(title, "修复损坏的会话日志")
        self.assertTrue(response.ok)
        self.assertEqual(requests[0][1]["max_tokens"], 96)
        self.assertIn("3-6", requests[0][0][0]["content"])


if __name__ == "__main__":
    unittest.main()
