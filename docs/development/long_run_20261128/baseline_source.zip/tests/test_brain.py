"""大脑测试：动作协议解析、阶段机推进、以及用回放后端的完整 ReAct 闭环。"""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from trina.audit import AuditLog
from trina.brain.agent import PentestAgent
from trina.brain.planner import Planner
from trina.brain.prompts import build_runtime_context, build_system_prompt, parse_action
from trina.config import TrinaConfig, LLMConfig
from trina.llm.replay_backend import ReplayBackend
from trina.scope import ScopeGuard
from trina.state import Finding, RunState
from trina.tools.registry import ParamSpec, Tool, ToolResult, ToolSpec


# ---------------------------------------------------------------------------
# 动作协议解析
# ---------------------------------------------------------------------------


class TestParseAction(unittest.TestCase):
    def test_runtime_action_examples_are_valid_json_with_or_without_ledger(self):
        from trina.brain.prompts import render_action_contract
        for chat in (False, True):
            for ledger in (False, True):
                with self.subTest(chat=chat, ledger=ledger):
                    text = render_action_contract(ledger, chat=chat)
                    start = text.index('{"action"')
                    action, _ = json.JSONDecoder().raw_decode(text[start:])
                    self.assertIn("action", action)
                    self.assertEqual("hypothesis" in action, ledger)
                    self.assertNotIn("渗透测试助手", text)
                    self.assertNotIn("你是 Trina", text)
                    self.assertNotIn("thought", action)
                    self.assertLess(len(text), 400)

    def test_system_messages_define_the_general_agent_modules(self):
        from trina.brain.chat import render_chat_prompt
        from trina.brain.prompts import render_system_prompt

        task_prompt = render_system_prompt()
        self.assertEqual(render_chat_prompt(), task_prompt)
        self.assertIn("通用的自主 Agent Runtime", task_prompt)
        self.assertNotIn("安全工程师", task_prompt)
        self.assertIn("普通问候", task_prompt)
        self.assertIn("真实回执", task_prompt)
        self.assertIn("两个及以上互不依赖的分支", task_prompt)
        self.assertIn("主动分别派发", task_prompt)
        self.assertIn("统一结果契约", task_prompt)
        self.assertIn("同批独立的本地读取可由执行器并发完成", task_prompt)
        for section in ("Engineering", "Tool Policy", "Exploration", "Delegation", "Workflow", "Delivery", "Completeness"):
            self.assertIn(f"# {section}", task_prompt)

    def test_task_route_is_task_scoped_and_selects_binary_or_web_guidance(self):
        from trina.brain.prompts import build_prompt_layers, infer_task_route, infer_task_route_key

        binary = infer_task_route("用 gdb 分析 ELF 并验证 ROP", "challenge.elf",
                                  tool_names=("binary_open", "debug_start"), categories=("binary",))
        web = infer_task_route("检查登录接口和 SQL 参数", "https://example.test",
                               tool_names=("http_fingerprint", "sqli_test"), categories=("web", "browser"))
        self.assertIn("Binary/Pwn/Reverse", binary)
        self.assertIn("Web/API", web)
        self.assertIn("确认文件类型", binary)
        self.assertIn("Pwn execution guidance", binary)
        self.assertIn("完整候选", binary)
        self.assertIn("第一轮先运行一次", binary)
        self.assertIn("HTTP/API 入口", web)
        ctf = infer_task_route("读取 challenge.py 并用 verifier.py 校验 flag", "127.0.0.1")
        self.assertIn("CTF 文件题", ctf)
        self.assertIn("批量读取", ctf)
        generalized_ctf = infer_task_route("读取 puzzle.py 并用 check.py 校验 token", "127.0.0.1")
        self.assertIn("CTF 文件题", generalized_ctf)
        generic_ctf = infer_task_route("读取 answer.py 并用 validator.py 验证 token", "127.0.0.1")
        self.assertIn("CTF 文件题", generic_ctf)
        pwn_route = infer_task_route_key(
            "解决本地 pwn 题，目录提供 exploit.py，优先运行并验证 flag",
            "file://pwn1",
            tool_names=("terminal_exec", "workspace_read_many", "binary_open"),
            categories=("binary", "workspace", "utility"),
        )
        self.assertEqual(pwn_route, "binary")

        layers = build_prompt_layers(protocol="native", task_route=binary)
        self.assertNotIn("Binary/Pwn/Reverse", layers.system())
        self.assertIn("Binary/Pwn/Reverse", layers.first_user())

    def test_code_route_uses_small_edit_and_test_surface(self):
        from trina.brain.prompts import infer_task_route_key
        from trina.tools import build_registry
        from trina.tools.profile import visible_tool_names

        registry = build_registry()
        route = infer_task_route_key(
            "Fix buggy.py and run python3 -m unittest -v", "buggy.py",
            tool_names=registry.names(), categories=registry.by_category().keys(),
        )
        self.assertEqual(route, "code")
        visible = visible_tool_names(registry, route)
        self.assertIn("workspace_edit", visible)
        self.assertIn("workspace_edit_many", visible)
        self.assertIn("terminal_exec", visible)
        self.assertNotIn("http_fingerprint", visible)
        self.assertNotIn("record_finding", visible)

    def test_binary_route_prefetches_existing_scripts_without_web_tools(self):
        from trina.tools import build_registry
        from trina.tools.profile import visible_tool_names

        registry = build_registry()
        visible = visible_tool_names(registry, "binary")
        self.assertIn("workspace_read_many", visible)
        self.assertIn("terminal_exec", visible)
        self.assertNotIn("web_search", visible)
        self.assertNotIn("browser_open", visible)

    def test_plain_json(self):
        action = parse_action('{"thought": "扫端口", "action": "port_scan", "params": {"target": "127.0.0.1"}}')
        self.assertEqual(action["action"], "port_scan")
        self.assertEqual(action["params"]["target"], "127.0.0.1")

    def test_fenced_json(self):
        text = '```json\n{"thought": "t", "action": "poc_scan", "params": {}}\n```'
        self.assertEqual(parse_action(text)["action"], "poc_scan")

    def test_json_after_prose(self):
        text = '我先想想。\n{"thought": "收尾", "final": {"status": "success", "summary": "done"}}\n结束。'
        action = parse_action(text)
        self.assertIn("final", action)
        self.assertEqual(action["final"]["status"], "success")

    def test_last_valid_object_wins(self):
        text = '{"thought":"草稿","action":"a"}\n{"thought":"最终","action":"b","params":{}}'
        self.assertEqual(parse_action(text)["action"], "b")

    def test_braces_inside_strings(self):
        text = '{"thought": "payload 里有 } 和 {", "action": "sqli_test", "params": {"url": "http://x/?a={\\"b\\":1}"}}'
        self.assertEqual(parse_action(text)["action"], "sqli_test")

    def test_complete_dsml_tool_call_is_recovered_as_action(self):
        text = (
            '<｜DSML｜tool_calls><｜DSML｜invoke name="poc_scan">'
            '<｜DSML｜parameter name="params" string="false">'
            '{"url":"https://example.test","hypothesis":{"statement":"验证入口","target":"example.test"}}'
            '</｜DSML｜parameter></｜DSML｜invoke></｜DSML｜tool_calls>'
        )
        action = parse_action(text)
        self.assertEqual(action["action"], "poc_scan")
        self.assertEqual(action["params"], {"url": "https://example.test"})
        self.assertEqual(action["hypothesis"]["statement"], "验证入口")

    def test_gateway_expanded_dsml_delimiters_are_not_rendered_as_text(self):
        text = (
            '< | | DSML | | calls>< | | DSML | | invoke name="poc_scan">'
            '< | | DSML | | parameter name="params" string="false">'
            '{"url":"https://example.test"}'
            '</ | | DSML | | parameter></ | | DSML | | invoke></ | | DSML | | calls>'
        )
        action = parse_action(text)
        self.assertEqual(action["action"], "poc_scan")
        self.assertEqual(action["params"], {"url": "https://example.test"})

    def test_incomplete_dsml_is_protocol_error_not_plain_answer(self):
        action = parse_action('<|DSML|invoke name="poc_scan"><|DSML|parameter name="params">{')
        self.assertEqual(action.get("protocol"), "dsml")
        self.assertIn("error", action)

    def test_garbage(self):
        action = parse_action("完全不是 JSON")
        self.assertIn("error", action)
        self.assertIn("raw", action)

    def test_missing_fields(self):
        self.assertIn("error", parse_action('{"foo": 1}'))

    def test_empty(self):
        self.assertIn("error", parse_action(""))


# ---------------------------------------------------------------------------
# 阶段机
# ---------------------------------------------------------------------------


class TestPlanner(unittest.TestCase):
    def setUp(self):
        self.state = RunState(run_id="p", target="127.0.0.1")

    def test_recon_to_enum_requires_ports(self):
        planner = Planner(max_steps_per_phase=5)
        phase, note = planner.tick(self.state, new_facts=False)
        self.assertEqual(phase, "recon")
        self.assertIsNone(note)
        self.state.host("127.0.0.1").add_port(80, service="http")
        phase, note = planner.tick(self.state, new_facts=True)
        self.assertEqual(phase, "enum")
        self.assertIn("recon", note)

    def test_enum_requires_surface_not_just_hosts(self):
        planner = Planner(max_steps_per_phase=5)
        planner.phase = "enum"
        self.state.host("127.0.0.1").add_port(22, service="ssh")
        phase, note = planner.tick(self.state, new_facts=False)
        self.assertEqual(phase, "enum", "只有主机与端口不算枚举完成")
        self.state.host("127.0.0.1").technologies.append("ssh")
        phase, _ = planner.tick(self.state, new_facts=True)
        self.assertEqual(phase, "vuln")

    def test_vuln_needs_verified_or_three_steps(self):
        planner = Planner(max_steps_per_phase=6)
        planner.phase = "vuln"
        self.state.findings.append(Finding(id="TRINA-001", title="t", vuln_class="git_leak", status="detected"))
        phase, _ = planner.tick(self.state, new_facts=True)
        self.assertEqual(phase, "vuln", "仅有未验证线索时不应立刻前移")
        self.state.findings[0].status = "verified"
        phase, _ = planner.tick(self.state, new_facts=True)
        self.assertEqual(phase, "exploit")

    def test_budget_forces_advance(self):
        planner = Planner(max_steps_per_phase=2)
        planner.phase = "enum"
        planner.tick(self.state, new_facts=False)
        phase, note = planner.tick(self.state, new_facts=False)
        self.assertEqual(phase, "vuln")
        self.assertIn("预算", note)

    def test_force_advance(self):
        planner = Planner(max_steps_per_phase=9)
        planner.phase = "recon"
        planner.force_advance()
        phase, note = planner.tick(self.state, new_facts=False)
        self.assertEqual(phase, "enum")
        self.assertIn("停滞", note)

    def test_should_finish_after_flags_in_post(self):
        planner = Planner()
        planner.phase = "post"
        self.state.flags.append({"value": "flag{x}"})
        self.assertTrue(planner.should_finish(self.state))
        planner.phase = "recon"
        self.assertFalse(planner.should_finish(self.state))

    def test_step_keeps_known_ports_without_repeating_action_protocol(self):
        from trina.brain.prompts import build_step_prompt
        self.state.host("127.0.0.1").add_port(80, service="http")
        prompt = build_step_prompt(state_digest=self.state.summary_for_prompt(), last_observation="HTTP 200",
                                   hints=["检查首页"], budget={"剩余秒": 30})
        self.assertIn("80/http", prompt)
        self.assertIn("HTTP 200", prompt)
        self.assertIn("检查首页", prompt)
        self.assertIn("剩余秒=30", prompt)
        self.assertNotIn('{"action"', prompt)
        self.assertNotIn("先用 port_scan", prompt)


# ---------------------------------------------------------------------------
# 目标要求
# ---------------------------------------------------------------------------


class TestGoalRequirements(unittest.TestCase):
    def test_parse_extracts_class_and_path(self):
        from trina.brain.goal import GoalRequirements

        req = GoalRequirements.parse("确认 http://127.0.0.1/sqli 的 SQL 注入并给出证据")
        self.assertIn("sqli", req.classes)
        self.assertIn("/sqli", req.paths)

    def test_nested_and_dotfile_paths(self):
        from trina.brain.goal import GoalRequirements

        req = GoalRequirements.parse("读取 /.git/HEAD 与 /admin/config.php")
        self.assertIn("/.git/head", req.paths)
        self.assertIn("/admin/config.php", req.paths)

    def test_flag_goal_has_no_hard_requirement(self):
        from trina.brain.goal import GoalRequirements

        self.assertTrue(GoalRequirements.parse("请拿到 flag").empty)

    def test_credentials_extracted_from_goal(self):
        from trina.brain.goal import GoalRequirements

        labeled = GoalRequirements.parse("对 127.0.0.1:2222 的 SSH 服务验证弱口令（用户名 trina、口令 trina123）")
        self.assertIn(("trina", "trina123"), labeled.credentials)
        self.assertTrue(any("trina/trina123" in hint for hint in labeled.credential_hints()))
        self.assertIn(("admin", "admin123"), GoalRequirements.parse("验证弱口令 admin/admin123").credentials)
        # 路径里的 "a/b" 不应被当成凭据
        self.assertEqual(GoalRequirements.parse("读取 /admin/config.php").credentials, [])

    def test_port_requirements_extracted_and_ignored_when_unrelated(self):
        from trina.brain.goal import GoalRequirements

        req = GoalRequirements.parse('枚举 127.0.0.1 的端口，必须覆盖 port:9099(HTTP) 与 127.0.0.1:2222(SSH)')
        self.assertEqual(sorted(req.ports), [2222, 9099])
        # 年份/时长/任务编号、题目 ID、实例 UUID 和文件路径不是端口。
        for text in (
            "在 2026 年完成，限时 1800 秒",
            "复现 TSecBench 题 web-0001",
            "AUTHORED-31FB487C，实例 UUID 8105/23，文件 /root/TPCTF2026-Agent/state/challenges/8105",
        ):
            self.assertEqual(GoalRequirements.parse(text).ports, [], text)

    def test_port_requirement_blocks_until_scanned(self):
        from trina.brain.goal import GoalRequirements

        state = RunState(run_id="p", target="127.0.0.1")
        req = GoalRequirements.parse("必须覆盖 port:9099 与 127.0.0.1:2222")
        self.assertEqual(sorted(req.ports), [2222, 9099])
        self.assertEqual(len(req.unsatisfied(state)), 2)
        state.host("127.0.0.1").add_port(9099, service="http")
        self.assertEqual(len(req.unsatisfied(state)), 1)
        state.host("127.0.0.1").add_port(2222, service="ssh")
        self.assertEqual(req.unsatisfied(state), [])

    def test_class_requirement_needs_evidenced_finding(self):
        from trina.brain.goal import GoalRequirements

        state = RunState(run_id="g", target="127.0.0.1")
        req = GoalRequirements.parse("确认 /sqli 的 SQL 注入")
        self.assertTrue(req.unsatisfied(state))
        # 只有「发现」但没有证据 → 仍不算达成
        state.add_finding({"vuln_class": "sqli", "url": "http://127.0.0.1/sqli", "parameter": "id", "status": "detected"})
        self.assertTrue(req.unsatisfied(state))
        # 已验证 + 有证据 → 达成
        state.add_finding(
            {
                "vuln_class": "sqli",
                "url": "http://127.0.0.1/sqli",
                "parameter": "id",
                "status": "verified",
                "evidence": [{"kind": "http", "target": "http://127.0.0.1/sqli?id=1'"}],
            }
        )
        self.assertFalse(req.unsatisfied(state))

    def test_path_only_requirement_is_hard(self):
        from trina.brain.goal import GoalRequirements

        state = RunState(run_id="g", target="127.0.0.1")
        req = GoalRequirements.parse("读取 /admin/config.php 的内容")
        self.assertFalse(req.classes, "该目标文本不含漏洞类关键词，应只有路径要求")
        self.assertIn("/admin/config.php", req.paths)
        self.assertTrue(req.unsatisfied(state), "无类要求时路径要求是硬条件")
        state.add_finding({"vuln_class": "lfi", "url": "http://127.0.0.1/admin/config.php", "evidence": [{"kind": "http"}]})
        self.assertEqual(req.unsatisfied(state), [])

    def test_path_requirement_is_soft_when_class_present(self):
        from trina.brain.goal import GoalRequirements

        state = RunState(run_id="g", target="127.0.0.1")
        req = GoalRequirements.parse("确认 /sqli 的 SQL 注入，并读取 /robots.txt")
        state.add_finding(
            {"vuln_class": "sqli", "url": "http://127.0.0.1/sqli", "parameter": "id", "status": "verified", "evidence": [{"kind": "http"}]}
        )
        self.assertEqual(req.unsatisfied(state), [])
        self.assertTrue(any("/robots.txt" in hint for hint in req.soft_hints(state)))


# ---------------------------------------------------------------------------
# ReAct 闭环（回放后端，无网络）
# ---------------------------------------------------------------------------


class _FakeTool(Tool):
    spec = ToolSpec(
        name="fake_scan",
        summary="假扫描器",
        category="recon",
        action_level="detect",
        params={"target": ParamSpec("str", "目标", required=True)},
    )

    def run(self, ctx, target):
        return ToolResult(
            ok=True,
            summary=f"扫到 80 端口 @ {target}",
            facts={"ports": [{"host": target, "port": 80, "service": "http"}]},
        )


class _LeakTool(Tool):
    spec = ToolSpec(
        name="fake_leak",
        summary="假 flag 读取",
        category="exploit",
        action_level="verify",
        params={"target": ParamSpec("str", "目标", required=True)},
    )

    def run(self, ctx, target):
        return ToolResult(ok=True, summary="拿到 flag", facts={"flags": [{"value": "flag{test_ok}", "source": "fake"}]})


class _SqliTool(Tool):
    """产出「已验证的 SQL 注入」事实，用于验证目标达成判定。"""

    spec = ToolSpec(
        name="fake_sqli",
        summary="假注入验证",
        category="exploit",
        action_level="verify",
        params={"url": ParamSpec("str", "目标 URL", required=True)},
    )

    def run(self, ctx, url):
        return ToolResult(
            ok=True,
            summary=f"SQL 注入已验证 @ {url}",
            facts={
                "findings": [
                    {
                        "title": "SQL 注入",
                        "vuln_class": "sqli",
                        "url": url,
                        "parameter": "id",
                        "severity": "high",
                        "status": "verified",
                        "evidence": [{"kind": "http", "target": url, "note": "报错回显"}],
                    }
                ]
            },
        )


class TestReActLoop(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfg = TrinaConfig.load()
        self.cfg.run.workspace = str(Path(self.tmp.name) / "runs")
        self.cfg.audit.dir = str(Path(self.tmp.name) / "logs")
        self.cfg.llm.max_steps = 8

    def tearDown(self):
        self.tmp.cleanup()

    def _agent(self, script: list[dict], tools=None) -> PentestAgent:
        from trina.tools.registry import ToolRegistry

        script_path = Path(self.tmp.name) / "replay.yaml"
        script_path.write_text(json.dumps({"steps": script}, ensure_ascii=False), encoding="utf-8")
        backend = ReplayBackend(LLMConfig(backend="replay", replay_script=str(script_path)))
        return PentestAgent(self.cfg, registry=ToolRegistry(tools or [_FakeTool(), _LeakTool(), _SqliTool()]), backend=backend)

    def test_binary_prefetch_runs_provided_pwn_script_before_model(self):
        """Pwn 题先取得真实脚本回执，再把结果交给首轮模型。"""
        from trina.tools import build_registry

        project = Path(self.tmp.name) / "pwn-project"
        project.mkdir()
        (project / "README.md").write_text("run exploit.py", encoding="utf-8")
        (project / "pwn1").write_bytes(b"ELF test fixture")
        (project / "exploit.py").write_text("print('flag{preflight}')\n", encoding="utf-8")
        script_path = Path(self.tmp.name) / "preflight-replay.yaml"
        script_path.write_text(json.dumps({"steps": [
            {"response": '{"final":{"status":"success","summary":"预执行回执已取得"}}'},
        ]}, ensure_ascii=False), encoding="utf-8")
        cfg = self.cfg.with_overrides(llm__replay_script=str(script_path), llm__backend="replay")
        original_cwd = Path.cwd()
        os.chdir(project)
        try:
            agent = PentestAgent(cfg, registry=build_registry(), backend=ReplayBackend(cfg.llm))
            state = agent.run(
                "file://pwn1",
                goal="解决本地 pwn 题，目录提供 exploit.py，优先运行并验证 flag",
                max_steps=1,
                max_seconds=15,
                run_id="binary-preflight",
            )
        finally:
            os.chdir(original_cwd)
        self.assertEqual(state.status, "success")
        self.assertEqual([item["value"] for item in state.flags], ["flag{preflight}"])
        self.assertTrue(any("已先运行题目提供的 exploit.py" in item.get("text", "") for item in state.timeline))
        self.assertEqual(state.counters["llm_calls"], 1)

    def test_full_loop_reaches_success(self):
        agent = self._agent(
            [
                {"response": '{"thought": "先扫端口", "action": "fake_scan", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "拿 flag", "action": "fake_leak", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "完成", "final": {"status": "success", "summary": "拿到 flag"}}'},
            ]
        )
        state = agent.run("127.0.0.1", goal="拿 flag")
        self.assertEqual(state.status, "success")
        self.assertEqual(len(state.flags), 1)
        self.assertIn(80, state.hosts["127.0.0.1"].ports)
        self.assertEqual(state.counters["llm_calls"], 3)
        self.assertEqual(state.counters["tool_calls"], 2)
        self.assertTrue(Path(state.artifacts["state_file"]).exists())
        # 审计链必须完整
        from trina.audit import AuditLog

        log = AuditLog(Path(state.artifacts["audit_path"]), state.run_id)
        ok, detail = log.verify()
        self.assertTrue(ok, detail)

    def test_resume_state_inherits_facts_but_starts_a_fresh_model_chain(self):
        first = self._agent([
            {"response": '{"action": "fake_scan", "params": {"target": "127.0.0.1"}, "hypothesis": {"statement": "发现服务"}}'},
            {"response": '{"final": {"status": "partial", "summary": "继续"}}'},
        ]).run("127.0.0.1", goal="拿 flag", run_id="attempt-one", max_steps=2)
        second_agent = self._agent([
            {"response": '{"action": "fake_leak", "params": {"target": "127.0.0.1"}}'},
            {"response": '{"final": {"status": "success", "summary": "完成"}}'},
        ])
        captured: list[list[dict[str, str]]] = []
        original = second_agent.backend.complete_messages

        def capture(messages, **kwargs):
            captured.append([dict(item) for item in messages])
            return original(messages, **kwargs)

        second_agent.backend.complete_messages = capture  # type: ignore[method-assign]
        first_snapshot = json.loads(json.dumps(first.to_dict()))
        second = second_agent.run(
            "127.0.0.1", goal="拿 flag", run_id="attempt-two", max_steps=2,
            resume_state=first,
        )
        self.assertEqual(second.status, "success")
        self.assertIn(80, second.hosts["127.0.0.1"].ports)
        self.assertEqual(len(second.flags), 1)
        self.assertEqual(second.counters["decision_rounds"], 4)
        self.assertEqual(second.ledger["calls"], 4)
        self.assertEqual([item["index"] for item in second.steps if "index" in item], [1, 2, 3, 4])
        self.assertEqual([item["index"] for item in first.steps if "index" in item], [1, 2], "续轮不得修改原检查点")
        self.assertEqual(second.hypotheses[0]["statement"], "发现服务")
        self.assertEqual([item["role"] for item in captured[0][:3]], ["system", "user", "user"])
        prompt = "\n".join(item["content"] for item in captured[0])
        self.assertIn('"80"', prompt, "续轮首个状态检查点必须包含上一轮事实")
        self.assertIn("fake_scan", prompt, "续轮应继承近期执行经验，避免盲目重复")
        self.assertNotIn("attempt-one", captured[0][0]["content"], "旧对话不得拼入新 system")
        self.assertEqual(first.to_dict(), first_snapshot, "续轮不得改写原始证据或假设")
        with self.assertRaisesRegex(ValueError, "目标"):
            second_agent.run("other.test", resume_state=first)

    def test_agent_sends_general_system_and_runtime_contract_as_user_data(self):
        agent = self._agent([
            {"response": '{"final": {"status": "partial", "summary": "done"}}'},
        ])
        original = agent.backend.complete_messages
        calls: list[list[dict[str, str]]] = []

        def capture(messages, **kwargs):
            calls.append([dict(item) for item in messages])
            return original(messages, **kwargs)

        agent.backend.complete_messages = capture  # type: ignore[method-assign]
        agent.run("127.0.0.1", max_steps=1)
        self.assertTrue(calls)
        self.assertTrue(all("# Tool Policy" in call[0]["content"] for call in calls))
        self.assertTrue(all("通用的自主 Agent Runtime" in call[0]["content"] for call in calls))
        self.assertEqual([item["role"] for item in calls[0][:3]], ["system", "user", "user"])
        self.assertIn("# 工具协议", calls[0][1]["content"])
        self.assertIn("# 可用工具", calls[0][1]["content"])
        self.assertNotIn("[user]", "\n".join(item["content"] for item in calls[0]))

    def test_commander_brief_is_visible_without_merging_foreign_facts(self):
        agent = self._agent([{"response": '{"final": {"status": "partial", "summary": "done"}}'}])
        calls: list[list[dict[str, str]]] = []
        original = agent.backend.complete_messages

        def capture(messages, **kwargs):
            calls.append([dict(item) for item in messages])
            return original(messages, **kwargs)

        agent.backend.complete_messages = capture  # type: ignore[method-assign]
        brief = {
            "version": 1,
            "source_task": "other",
            "source_run_id": "other-run",
            "source_target": "http://other.test",
            "destination_task": "current",
            "similarity": 0.75,
            "reasons": ["验证方向高度相似"],
            "intelligence": {
                "assets": [{"host": "other.test", "ports": {"80": {"service": "http"}}}],
                "verified_findings": [],
            },
        }
        state = agent.run("127.0.0.1", max_steps=1, commander_briefs=[brief])
        prompt = "\n".join(item["content"] for item in calls[0])
        self.assertIn("Commander 转发情报", prompt)
        self.assertIn("other.test", prompt)
        self.assertNotIn("other.test", state.hosts)
        records = [json.loads(line) for line in Path(state.artifacts["audit_path"]).read_text(encoding="utf-8").splitlines()]
        self.assertTrue(any(item.get("event") == "context.commander.forward" for item in records))

    def test_commander_can_forward_new_intelligence_during_a_run(self):
        agent = self._agent([
            {"response": '{"action": "fake_scan", "params": {"target": "127.0.0.1"}}'},
            {"response": '{"final": {"summary": "done"}}'},
        ])
        prompts: list[list[dict[str, str]]] = []
        original = agent.backend.complete_messages

        def capture(messages, **kwargs):
            prompts.append([dict(item) for item in messages])
            return original(messages, **kwargs)

        calls = 0
        brief = {
            "version": 1,
            "source_task": "just-finished",
            "source_run_id": "source-run",
            "source_target": "127.0.0.1",
            "destination_task": "current",
            "similarity": 0.95,
            "reasons": ["规范化目标相同"],
            "intelligence": {"assets": [{"host": "127.0.0.1", "web_paths": ["/new"]}]},
        }

        def provider():
            nonlocal calls
            calls += 1
            return [] if calls == 1 else [brief]

        agent.backend.complete_messages = capture  # type: ignore[method-assign]
        agent.run("127.0.0.1", max_steps=2, commander_brief_provider=provider)
        self.assertNotIn("just-finished", "\n".join(item["content"] for item in prompts[0]))
        self.assertIn("just-finished", "\n".join(item["content"] for item in prompts[1]))
        self.assertEqual(prompts[1][:len(prompts[0])], prompts[0], "第二次请求必须严格继承第一次消息前缀")

    def test_minimal_actions_execute_without_thought_or_role_fields(self):
        agent = self._agent([
            {"response": json.dumps({"action": "fake_scan", "params": {"target": "127.0.0.1"}})},
            {"response": json.dumps({"action": "fake_leak", "params": {"target": "127.0.0.1"}})},
            {"response": json.dumps({"final": {"summary": "done"}})},
        ])
        state = agent.run("127.0.0.1", goal="拿 flag")
        self.assertEqual(state.status, "success")
        self.assertEqual(state.counters["tool_calls"], 2)
        self.assertEqual(len(state.flags), 1)

    def test_out_of_scope_is_blocked_without_llm(self):
        self.cfg.scope.trust_mode = "restricted"
        agent = self._agent([{"response": '{"thought": "x", "final": {}}'}])
        state = agent.run("8.8.8.8")
        self.assertEqual(state.status, "blocked")
        self.assertEqual(state.counters["llm_calls"], 0)

    def test_denied_action_gets_hints_and_loop_continues(self):
        # fake_leak 需要 verify 级，这里把上限压到 detect，动作应被拒绝但循环继续
        self.cfg.scope.trust_mode = "restricted"
        self.cfg.scope.exploit_level = "detect"
        agent = self._agent(
            [
                {"response": '{"thought": "越级尝试", "action": "fake_leak", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "改走合规路径", "final": {"status": "partial", "summary": "被拒后结束"}}'},
            ]
        )
        state = agent.run("127.0.0.1")
        self.assertGreaterEqual(state.counters["denied"], 1)
        self.assertEqual(state.status, "partial")

    def test_invalid_json_is_recovered(self):
        agent = self._agent(
            [
                {"response": "我不会输出 JSON"},
                {"response": '{"thought": "改正", "action": "fake_scan", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "完成", "final": {"status": "partial", "summary": "ok"}}'},
            ]
        )
        state = agent.run("127.0.0.1")
        self.assertGreaterEqual(state.counters["errors"], 1)
        self.assertIn(80, state.hosts["127.0.0.1"].ports)

    def test_stall_detection_injects_correction(self):
        repeat = '{"thought": "重复", "action": "fake_scan", "params": {"target": "127.0.0.1"}}'
        agent = self._agent([{"response": repeat} for _ in range(8)])
        state = agent.run("127.0.0.1", max_steps=6)
        hints = [item["text"] for item in state.timeline if item["kind"] == "hint"]
        self.assertTrue(any("必须改变策略" in hint for hint in hints), hints)

    def test_flag_shortcut_does_not_satisfy_task_goal(self):
        """目标要求「验证 /sqli 的注入」时，仅拿到 flag 不得判定成功或提前收敛。"""
        agent = self._agent(
            [
                {"response": '{"thought": "直接读 flag", "action": "fake_leak", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "有 flag 了，收工", "final": {"status": "success", "summary": "拿到 flag"}}'},
            ]
        )
        state = agent.run("127.0.0.1", goal="确认 http://127.0.0.1/sqli 的 SQL 注入并给出证据")
        self.assertNotEqual(state.status, "success", "目标未达成时不得判成功")
        self.assertGreaterEqual(state.counters["denied"], 0)
        actions = [step.get("action") for step in state.steps]
        self.assertIn("final_rejected", actions, "提前结束请求应被拒绝一次")
        notes = " ".join(item["text"] for item in state.timeline if item["kind"] == "goal")
        self.assertIn("sqli", notes)

    def test_goal_satisfied_yields_success(self):
        agent = self._agent(
            [
                {"response": '{"thought": "验证注入", "action": "fake_sqli", "params": {"url": "http://127.0.0.1/sqli?id=1"}}'},
                {"response": '{"thought": "完成", "final": {"status": "success", "summary": "注入已验证"}}'},
            ]
        )
        state = agent.run("127.0.0.1", goal="确认 http://127.0.0.1/sqli 的 SQL 注入并给出证据")
        self.assertEqual(state.status, "success")
        self.assertEqual([f.vuln_class for f in state.findings], ["sqli"])

    def test_no_goal_keeps_flag_shortcut_success(self):
        """无明确任务要求时，拿到 flag 仍然是成功（保持原有语义）。"""
        agent = self._agent(
            [
                {"response": '{"thought": "读 flag", "action": "fake_leak", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "完成", "final": {"status": "success", "summary": "拿到 flag"}}'},
            ]
        )
        state = agent.run("127.0.0.1", goal="拿到 flag")
        self.assertEqual(state.status, "success")
        self.assertEqual(len(state.flags), 1)

    def test_mid_run_pivot_to_out_of_scope_is_denied(self):
        """预检只覆盖起始目标：模型中途换目标也必须被逐动作拦下并留痕。"""
        self.cfg.scope.trust_mode = "restricted"
        agent = self._agent(
            [
                {"response": '{"thought": "顺手扫隔壁", "action": "fake_scan", "params": {"target": "8.8.8.8"}}'},
                {"response": '{"thought": "收回", "final": {"status": "partial", "summary": "已改回授权范围"}}'},
            ]
        )
        state = agent.run("127.0.0.1")
        self.assertGreaterEqual(state.counters["denied"], 1)
        self.assertNotIn("8.8.8.8", state.hosts)
        from trina.audit import AuditLog

        log = AuditLog(Path(state.artifacts["audit_path"]), state.run_id)
        events = [record.get("event") for record in log.read_all()]
        self.assertIn("guard.deny", events)
        self.assertIn("tool.denied", events)

    def test_record_round_trip_is_valid_json(self):
        """录制物是评测回归的输入，必须是合法 JSON 且能被回放后端直接加载。"""
        agent = self._agent(
            [
                {"response": '{"thought": "扫端口", "action": "fake_scan", "params": {"target": "127.0.0.1"}}'},
                {"response": '{"thought": "完成", "final": {"status": "partial", "summary": "ok"}}'},
            ]
        )
        record = Path(self.tmp.name) / "rec.json"
        agent.run("127.0.0.1", record_path=record)
        data = json.loads(record.read_text(encoding="utf-8"))
        self.assertEqual(len(data["steps"]), 2)
        backend = ReplayBackend(LLMConfig(backend="replay", replay_script=str(record)))
        self.assertEqual(len(backend.script), 2)

    def test_system_prompt_and_runtime_context_are_both_present(self):
        registry = type("R", (), {"prompt_block": lambda self=None: "### fake_scan"})()
        prompt = build_system_prompt(self.cfg.scope_prompt_block(), registry.prompt_block())
        self.assertIn("# Engineering", prompt)
        self.assertIn("# Completeness", prompt)
        runtime = build_runtime_context(self.cfg.scope_prompt_block(), registry.prompt_block())
        self.assertIn("信任模式: full", runtime)
        self.assertIn("fake_scan", runtime)
        self.assertIn(self.cfg.scope_prompt_block(), runtime)
        self.assertNotIn("你是", runtime)


if __name__ == "__main__":
    unittest.main()
